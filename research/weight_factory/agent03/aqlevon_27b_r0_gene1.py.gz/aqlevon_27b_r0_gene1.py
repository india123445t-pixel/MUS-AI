#!/usr/bin/env python3
"""AQLEVON 27B R0 Gene1 crystallization under the owner-authorized USD 8 mission.

This is a real parameter-changing AQLEVON 27B candidate run. It transfers the
successful Auth16 synthetic-curriculum recipe to the canonical Qwen3.8-27B base.
Worker05 sealed/private data is forbidden. Public indices 00..03 remain eval-only;
synthetic indices 04..19 are used for gradients.
"""
from __future__ import annotations

import argparse, gc, hashlib, importlib.util, json, math, os, random, re, time
from pathlib import Path
from typing import Any

MODEL_REPO = "Qwen/Qwen3.8-27B"
MODEL_REV = "1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0"
PACK_SHA = "35c7ebe6d5e82f42d7553fa28391f6d82c8800d6eced582d06881c8eb17d9d6b"
SEED = 2701
SYNTH_START, SYNTH_STOP = 4, 20
PROMPT_PERTURBATIONS = 3
CAP = 1024
LR, MIN_LR = 1.2e-5, 1.2e-6
LORA_R, LORA_ALPHA = 8, 16
MIN_COVERAGE_STEPS = 224
DEFAULT_TRAIN_BUDGET_SECONDS = 10800

def canonical_sha(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                                     allow_nan=False).encode()).hexdigest()

def sealed(obj: dict, field: str) -> dict:
    out = dict(obj); out[field] = canonical_sha(out); return out

def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n")

def sha_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1<<20), b""): h.update(b)
    return h.hexdigest()

def load_w02(path: Path):
    spec=importlib.util.spec_from_file_location("aqlevon_w02_27b", str(path))
    if spec is None or spec.loader is None: raise RuntimeError("cannot_load_w02")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def task_index(task: dict[str,Any]) -> int:
    m=re.search(r"-(\d{2})-hardened$", task["task_id"])
    if not m: raise RuntimeError("bad_task_id:"+task["task_id"])
    return int(m.group(1))

def strict_json_program(text: str):
    s=text.strip()
    if s.startswith("```") and s.endswith("```"):
        ls=s.splitlines()
        if len(ls)>=3 and ls[0].strip().lower() in {"```","```json"}:
            s="\n".join(ls[1:-1]).strip()
    try: v=json.loads(s)
    except Exception: return None
    return v if isinstance(v,list) and v else None

def verify_text(w02, task, text):
    p=strict_json_program(text)
    if p is None: return False,"invalid_json_program"
    core=w02._core(task["family"],task_index(task))
    r=w02.verify(task,core,p)
    return bool(r.get("passed")),str(r.get("reason"))

def load_public_tasks(pack_path: Path):
    pack=json.loads(pack_path.read_text())
    if pack.get("pack_sha256")!=PACK_SHA: raise RuntimeError("public_pack_sha_mismatch")
    tasks=[t for t in pack["tasks"] if t.get("verifier_mode")=="hardened" and t.get("training_eligible") is True]
    if len(tasks)!=56: raise RuntimeError(f"expected_56_public_tasks:{len(tasks)}")
    dev=sorted([t for t in tasks if task_index(t) in (0,1)], key=lambda x:x["task_id"])
    shadow=sorted([t for t in tasks if task_index(t) in (2,3)], key=lambda x:x["task_id"])
    if len(dev)!=28 or len(shadow)!=28: raise RuntimeError("bad_public_split")
    return dev,shadow

def build_synthetic_rows(w02):
    rows=[]
    for perturb in range(PROMPT_PERTURBATIONS):
        for family in w02.FAMILIES:
            for idx in range(SYNTH_START,SYNTH_STOP):
                core=w02._core(family,idx)
                task=w02._task(core,"hardened",training_visible=True)
                chk=w02.verify(task,core,core["oracle_program"])
                if not chk.get("passed"): raise RuntimeError(f"oracle_failed:{family}:{idx}")
                rows.append({
                    "task_id":f"synthetic-{family}-{idx:02d}-p{perturb}",
                    "prompt":w02._render_prompt(core,perturb),
                    "target":json.dumps(core["oracle_program"],ensure_ascii=False,separators=(",",":")),
                    "family":family,"synthetic_index":idx,"perturbation":perturb,
                    "source":"aqlevon_owned_synthetic_curriculum_27b",
                })
    if len(rows)!=672 or len({r["family"] for r in rows})!=14: raise RuntimeError("bad_synthetic_rows")
    return rows

def evaluate(model,tokenizer,w02,tasks,max_new_tokens=256):
    import torch
    model.eval(); passed=0; rec=[]
    for i,task in enumerate(tasks):
        prompt=tokenizer.apply_chat_template([{"role":"user","content":task["prompt"]}],
                                             tokenize=False,add_generation_prompt=True,
                                             enable_thinking=False)
        enc=tokenizer(prompt,return_tensors="pt",add_special_tokens=False).to("cuda")
        with torch.inference_mode():
            out=model.generate(**enc,do_sample=False,max_new_tokens=max_new_tokens,
                               use_cache=True,pad_token_id=tokenizer.eos_token_id)[0]
        text=tokenizer.decode(out[enc["input_ids"].shape[1]:],skip_special_tokens=True).strip()
        ok,reason=verify_text(w02,task,text); passed+=int(ok)
        rec.append({"task_id":task["task_id"],"passed":ok,"reason":reason,"text":text})
        print(f"AQLEVON_27B_EVAL {i+1}/{len(tasks)} id={task['task_id']} pass={int(ok)}",flush=True)
        del enc,out
    return {"successes":passed,"tasks":len(tasks),"pass_at_1":passed/len(tasks),"records":rec}

def state_hash(state):
    h=hashlib.sha256()
    for name in sorted(state):
        t=state[name].detach().cpu().contiguous().float()
        h.update(name.encode()); h.update(str(tuple(t.shape)).encode()); h.update(t.numpy().tobytes(order="C"))
    return h.hexdigest()

def run(args):
    if os.environ.get("AQLEVON_SEALED_EVAL_PATH") or os.environ.get("AQLEVON_EVAL_SECRET"):
        raise RuntimeError("sealed_eval_environment_forbidden")
    import torch
    import torch.nn.functional as F
    from peft import LoraConfig,PeftModel,TaskType,get_peft_model,get_peft_model_state_dict
    from transformers import AutoTokenizer,Qwen3_5ForConditionalGeneration

    if not torch.cuda.is_available() or not torch.cuda.is_bf16_supported(): raise RuntimeError("bf16_cuda_required")
    w02=load_w02(args.w02_module)
    dev,shadow=load_public_tasks(args.training_pack)
    rows=build_synthetic_rows(w02)
    random.seed(SEED); torch.manual_seed(SEED); torch.cuda.manual_seed_all(SEED)

    tokenizer=AutoTokenizer.from_pretrained(str(args.model_dir),local_files_only=True,trust_remote_code=False)
    base=Qwen3_5ForConditionalGeneration.from_pretrained(
        str(args.model_dir),dtype=torch.bfloat16,device_map={"":0},
        low_cpu_mem_usage=True,local_files_only=True,trust_remote_code=False)
    tc=base.config.text_config
    layers=list(tc.layer_types)
    full_layers=[i for i,k in enumerate(layers) if k=="full_attention"]
    if len(layers)!=64 or len(full_layers)!=16 or tc.hidden_size!=5120:
        raise RuntimeError(f"27b_topology_mismatch layers={len(layers)} full={full_layers} hidden={tc.hidden_size}")
    print("AQLEVON_27B_TOPOLOGY_PASS",full_layers,flush=True)

    dev_pre=evaluate(base,tokenizer,w02,dev)
    shadow_pre=evaluate(base,tokenizer,w02,shadow)
    print("AQLEVON_27B_BASELINE",json.dumps({"dev":dev_pre["successes"],"shadow":shadow_pre["successes"]}),flush=True)

    base.config.use_cache=False
    if hasattr(base.config,"text_config"): base.config.text_config.use_cache=False
    base.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant":False})
    for p in base.parameters(): p.requires_grad_(False)
    selected=[]
    for name,_ in base.named_modules():
        if name.startswith("model.language_model.layers.") and ".self_attn." in name and name.rsplit(".",1)[-1] in {"q_proj","v_proj"}:
            selected.append(name)
    selected=sorted(set(selected))
    if len(selected)!=32: raise RuntimeError(f"expected_32_qv_targets:{len(selected)}")
    expected_layers={int(n.split(".layers.",1)[1].split(".",1)[0]) for n in selected}
    if expected_layers!=set(full_layers): raise RuntimeError("target_layer_set_mismatch")
    lcfg=LoraConfig(r=LORA_R,lora_alpha=LORA_ALPHA,lora_dropout=0.0,bias="none",
                    target_modules=selected,task_type=TaskType.CAUSAL_LM,init_lora_weights=True)
    model=get_peft_model(base,lcfg); model.enable_input_require_grads()
    params=[p for p in model.parameters() if p.requires_grad]
    trainable=sum(p.numel() for p in params)
    print("AQLEVON_27B_LORA_PASS",len(selected),trainable,flush=True)

    optimizer=torch.optim.AdamW(params,lr=LR,weight_decay=0.03)
    eos=tokenizer.eos_token or "<|im_end|>"
    losses=[]; grads=[]; used=[]; global_step=0
    budget=max(900,int(args.train_budget_seconds))
    started=time.monotonic()
    model.train()
    for row in rows:
        if global_step>=MIN_COVERAGE_STEPS and time.monotonic()-started>=budget:
            print(f"AQLEVON_27B_ADAPTIVE_TIME_STOP step={global_step} elapsed={time.monotonic()-started:.1f}",flush=True)
            break
        optimizer.zero_grad(set_to_none=True)
        ptxt=tokenizer.apply_chat_template([{"role":"user","content":row["prompt"]}],
                                           tokenize=False,add_generation_prompt=True,enable_thinking=False)
        prefix=tokenizer(ptxt,add_special_tokens=False).input_ids
        target=tokenizer(row["target"]+eos,add_special_tokens=False).input_ids
        if not target or len(prefix)+len(target)>CAP: raise RuntimeError(f"sequence_cap:{row['task_id']}:{len(prefix)+len(target)}")
        ids=torch.tensor([prefix+target],device="cuda",dtype=torch.long)
        labels=torch.tensor([[-100]*len(prefix)+target],device="cuda",dtype=torch.long)
        logits=model(input_ids=ids,attention_mask=torch.ones_like(ids),use_cache=False).logits
        loss=F.cross_entropy(logits[:,:-1,:].float().reshape(-1,logits.shape[-1]),labels[:,1:].reshape(-1),ignore_index=-100)
        if not torch.isfinite(loss) or loss.item()<=0: raise RuntimeError(f"invalid_loss:{global_step+1}")
        loss.backward()
        grad=float(torch.nn.utils.clip_grad_norm_(params,1.0))
        if not math.isfinite(grad) or grad<=0: raise RuntimeError(f"invalid_grad:{global_step+1}")
        frac=global_step/max(1,len(rows)-1)
        lr=MIN_LR+(LR-MIN_LR)*(1+math.cos(math.pi*frac))/2
        for g in optimizer.param_groups:g["lr"]=lr
        optimizer.step(); global_step+=1
        losses.append(float(loss.detach())); grads.append(grad); used.append(row)
        if global_step==1 or global_step%25==0 or global_step in (224,448,672):
            print(f"AQLEVON_27B_UPDATE={global_step}/672 loss={losses[-1]:.6f} grad={grad:.6f} lr={lr:.8g} elapsed={time.monotonic()-started:.1f}",flush=True)
        del ids,labels,logits,loss
    if global_step<MIN_COVERAGE_STEPS: raise RuntimeError(f"insufficient_semantic_coverage:{global_step}")
    torch.cuda.synchronize()

    out=args.output_dir
    if out.exists(): raise RuntimeError("refuse_overwrite_output")
    art=out/"candidate_artifact"; art.mkdir(parents=True)
    model.save_pretrained(str(art),safe_serialization=True)
    tokenizer.save_pretrained(str(art))
    st=get_peft_model_state_dict(model)
    sh=state_hash(st)
    changed=sum(int(torch.count_nonzero(v).item()) for n,v in st.items() if ".lora_B." in n)
    if changed<=0: raise RuntimeError("no_lora_B_change")
    adapter_sha=sha_file(art/"adapter_model.safetensors")
    peak=int(torch.cuda.max_memory_allocated())
    del st,optimizer,model,base
    gc.collect(); torch.cuda.empty_cache()

    rebase=Qwen3_5ForConditionalGeneration.from_pretrained(
        str(args.model_dir),dtype=torch.bfloat16,device_map={"":0},
        low_cpu_mem_usage=True,local_files_only=True,trust_remote_code=False)
    cand=PeftModel.from_pretrained(rebase,str(art),is_trainable=False)
    rst=get_peft_model_state_dict(cand); rsh=state_hash(rst)
    if rsh!=sh: raise RuntimeError("save_reload_hash_mismatch")
    cand.config.use_cache=True
    dev_post=evaluate(cand,tokenizer,w02,dev)
    shadow_post=evaluate(cand,tokenizer,w02,shadow)

    def regressions(pre,post):
        a={r["task_id"]:bool(r["passed"]) for r in pre["records"]}
        b={r["task_id"]:bool(r["passed"]) for r in post["records"]}
        return sorted(k for k,v in a.items() if v and not b.get(k,False))
    dreg=regressions(dev_pre,dev_post); sreg=regressions(shadow_pre,shadow_post)
    dg=dev_post["successes"]-dev_pre["successes"]; sg=shadow_post["successes"]-shadow_pre["successes"]
    no_reg=not dreg and not sreg
    public_retention=bool(no_reg and dev_post["successes"]>=dev_pre["successes"] and shadow_post["successes"]>=shadow_pre["successes"])
    public_gain=bool(no_reg and (dg>=3 or sg>=3))
    status="READY_FOR_WORKER05_EVALUATION" if public_retention else "PUBLIC_GATE_FAILED"

    write_json(out/"synthetic_curriculum_used.json",used)
    write_json(out/"dev_pre_eval.json",dev_pre); write_json(out/"shadow_pre_eval.json",shadow_pre)
    write_json(out/"dev_post_eval.json",dev_post); write_json(out/"shadow_post_eval.json",shadow_post)
    receipt=sealed({
      "receipt_kind":"AQLEVON_27B_R0_GENE1_TRAINING_RECEIPT_V1",
      "base_repo":MODEL_REPO,"base_revision":MODEL_REV,"seed":SEED,
      "public_pack_sha256":PACK_SHA,"optimizer_updates":global_step,
      "training_presentations":len(used),"minimum_coverage_steps":MIN_COVERAGE_STEPS,
      "full_attention_layers":full_layers,"target_module_count":len(selected),
      "trainable_parameters":trainable,"lora_r":LORA_R,"lora_alpha":LORA_ALPHA,
      "lr":LR,"min_lr":MIN_LR,"adapter_state_sha256":sh,"reloaded_adapter_state_sha256":rsh,
      "save_reload_hash_match":True,"adapter_model_sha256":adapter_sha,"changed_lora_B_elements":changed,
      "dev_pre_successes":dev_pre["successes"],"dev_post_successes":dev_post["successes"],"dev_gain_tasks":dg,
      "shadow_pre_successes":shadow_pre["successes"],"shadow_post_successes":shadow_post["successes"],"shadow_gain_tasks":sg,
      "dev_regressions":dreg,"shadow_regressions":sreg,
      "public_retention_gate_pass":public_retention,"public_gain_observed":public_gain,
      "peak_vram_allocated_bytes":peak,
      "sealed_eval_consumed":False,"worker05_used_for_tuning":False,"capability_gain_claim":False
    },"receipt_sha256")
    write_json(out/"training_run_receipt.json",receipt)
    manifest=sealed({
      "manifest_kind":"AQLEVON_27B_R0_GENE1_CANDIDATE_V1","candidate_status":status,
      "model_name":"AQLEVON-27B-R0-GENE1","artifact_type":"adapter",
      "base_repo":MODEL_REPO,"base_revision":MODEL_REV,
      "training_receipt_sha256":sha_file(out/"training_run_receipt.json"),
      "adapter_config_sha256":sha_file(art/"adapter_config.json"),"adapter_model_sha256":adapter_sha,
      "adapter_state_sha256":sh,"reloaded_adapter_state_sha256":rsh,
      "save_reload_hash_match":True,"public_retention_gate_pass":public_retention,
      "public_gain_observed":public_gain,"sealed_eval_consumed":False,
      "worker05_used_for_tuning":False,"capability_gain_claim":False
    },"manifest_sha256")
    write_json(out/"candidate_artifact_manifest.json",manifest)
    print("AQLEVON_27B_PACKAGE_PASS",json.dumps({
      "status":status,"steps":global_step,"dev_pre":dev_pre["successes"],"dev_post":dev_post["successes"],
      "shadow_pre":shadow_pre["successes"],"shadow_post":shadow_post["successes"],
      "public_retention":public_retention,"public_gain":public_gain,
      "adapter_sha256":adapter_sha,"manifest_sha256":manifest["manifest_sha256"]
    },sort_keys=True),flush=True)

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--w02-module",type=Path,required=True)
    p.add_argument("--training-pack",type=Path,required=True)
    p.add_argument("--model-dir",type=Path,required=True)
    p.add_argument("--output-dir",type=Path,required=True)
    p.add_argument("--train-budget-seconds",type=int,default=DEFAULT_TRAIN_BUDGET_SECONDS)
    args=p.parse_args(); run(args)
if __name__=="__main__": main()
