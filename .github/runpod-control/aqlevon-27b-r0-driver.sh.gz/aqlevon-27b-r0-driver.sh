#!/usr/bin/env bash
set -euo pipefail
AUTH=.github/runpod-control/aqlevon-27b-r0-manager-authorization-20260926.json
TRIGGER=.github/runpod-control/execute-aqlevon-27b-r0-20260926.json
CONSUMED=.github/runpod-control/aqlevon-27b-r0-consumed-20260926.json
LIVE=.github/runpod-control/aqlevon-27b-r0-live-selection-20260926.json
RESULT=.github/runpod-control/aqlevon-27b-r0-run-result-20260926.json
AUTH_ID=AQLEVON-27B-R0-GENE1-RUNPOD-20260926-01
AUTH_SHA=469dca1993c7d5c04a91f98f05688642067bc52c895eae7a36630b2f62d81b8a
IMAGE_DIGEST=sha256:ad4f48dd206b317e09d8fe1a834e57e79c444f9f581ebd45179c4072cb0d66ec
pod=""
cleaned=0

cleanup() {
  status=$?
  if [ -n "$pod" ] && [ "$cleaned" != 1 ]; then
    echo "AQLEVON_27B_EXIT_CLEANUP pod=$pod status=$status"
    curl -sS -X POST "https://rest.runpod.io/v1/pods/$pod/stop" \
      -H "Authorization: Bearer $RUNPOD_API_KEY" -H 'Content-Type: application/json' -d '{}' >/tmp/exit-stop.json || true
    sleep 2
    curl -sS -X DELETE "https://rest.runpod.io/v1/pods/$pod" \
      -H "Authorization: Bearer $RUNPOD_API_KEY" >/tmp/exit-delete.json || true
  fi
  exit "$status"
}
trap cleanup EXIT

test -n "${RUNPOD_API_KEY:-}"
test ! -e "$CONSUMED"

python3 - <<'PY'
import hashlib,json
from pathlib import Path
a=json.loads(Path(".github/runpod-control/aqlevon-27b-r0-manager-authorization-20260926.json").read_text())
t=json.loads(Path(".github/runpod-control/execute-aqlevon-27b-r0-20260926.json").read_text())
payload={k:v for k,v in a.items() if k!="authorization_sha256"}
h=hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":"),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
assert h==a["authorization_sha256"]=="469dca1993c7d5c04a91f98f05688642067bc52c895eae7a36630b2f62d81b8a"
assert a["authorization_id"]==t["authorization_id"]=="AQLEVON-27B-R0-GENE1-RUNPOD-20260926-01"
assert a["single_use"] is True and a["training_authorized"] is True
assert a["base_repo"]=="Qwen/Qwen3.8-27B"
assert a["base_revision"]=="1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0"
assert a["gpu_id"]=="NVIDIA A100-SXM4-80GB"
assert a["profile"]=="1x80" and a["no_automatic_gpu_fallback"] is True
assert float(a["max_total_cost_usd"])<=7.20
assert float(a["mission_total_budget_usd"])==8.00
assert float(a["mission_paid_spend_before_this_authorization_usd"])+float(a["max_total_cost_usd"])<=8.00
assert a["sealed_eval_consumed"] is False and a["no_main_merge"] is True
print("AQLEVON_27B_AUTHORIZATION_CONTRACT_PASS")
PY

# Fail closed if any AQLEVON paid Pod is already active.
curl -fsS https://rest.runpod.io/v1/pods -H "Authorization: Bearer $RUNPOD_API_KEY" >/tmp/pods.json
python3 - <<'PY'
import json
p=json.load(open("/tmp/pods.json")); xs=p if isinstance(p,list) else p.get("pods") or p.get("items") or []
active=[x for x in xs if str(x.get("name","")).startswith("AQLEVON-") and str(x.get("desiredStatus") or x.get("status"))!="EXITED"]
assert not active,active
print("AQLEVON_27B_NO_ACTIVE_PODS_PASS")
PY

curl -sSL https://cli.runpod.net | sudo bash >/dev/null
runpodctl gpu list --output json >/tmp/gpus.json

python3 - <<'PY'
import datetime,json,math
from pathlib import Path
a=json.load(open(".github/runpod-control/aqlevon-27b-r0-manager-authorization-20260926.json"))
choices=[]
for g in json.load(open("/tmp/gpus.json")):
    gid=str(g.get("gpuId",""))
    if gid!="NVIDIA A100-SXM4-80GB" or not g.get("secureCloud"): continue
    price=float(g.get("securePricePerHr") or 999)
    if price>float(a["max_hourly_rate_usd"]): continue
    for d in g.get("dataCenterAvailability") or []:
        if str(d.get("stockStatus")).lower()!="none" and d.get("dataCenterId"):
            secs=min(int(a["max_billed_seconds"]),int(float(a["max_total_cost_usd"])*3600/price))
            if secs>=10800: choices.append((price,gid,str(d["dataCenterId"]),secs))
assert choices,"no_authorized_a100_80gb_secure_stock"
price,gpu,dc,secs=sorted(choices)[0]
out={
  "selected_gpu_id":gpu,"observed_capacity_datacenter":dc,
  "selected_price_hr":price,"dynamic_max_billed_seconds":secs,
  "max_total_cost_usd":a["max_total_cost_usd"],
  "mission_total_budget_usd":a["mission_total_budget_usd"],
  "selected_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat()
}
Path("/tmp/selected_gpu").write_text(gpu)
Path(".github/runpod-control/aqlevon-27b-r0-live-selection-20260926.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
print("AQLEVON_27B_LIVE_SELECTION",gpu,dc,price,secs)
PY

printf "%s" "$GITHUB_SHA" >/tmp/source_sha
BOOT_URL="https://raw.githubusercontent.com/india123445t-pixel/MUS-AI/$GITHUB_SHA/.github/runpod-control/aqlevon-27b-r0-bootstrap.sh.gz"
DOCKER_ARGS="bash -lc 'export AQLEVON_SOURCE_SHA=$GITHUB_SHA; curl -fsSL $BOOT_URL -o /tmp/aq27-bootstrap.sh.gz && gzip -dc /tmp/aq27-bootstrap.sh.gz > /tmp/aq27-bootstrap.sh && chmod +x /tmp/aq27-bootstrap.sh && exec bash /tmp/aq27-bootstrap.sh'"

runpodctl pod create \
  --name AQLEVON-27B-R0-GENE1-01 \
  --image "ghcr.io/india123445t-pixel/mus-ai@$IMAGE_DIGEST" \
  --gpu-id "$(cat /tmp/selected_gpu)" --gpu-count 1 --cloud-type SECURE \
  --container-disk-in-gb 120 --ports 8000/http --ssh=false \
  --docker-args "$DOCKER_ARGS" --output json > /tmp/create.json

python3 - <<'PY'
import datetime,json,time
from pathlib import Path
p=json.load(open("/tmp/create.json")); pod=p.get("id") or p.get("podId"); assert pod
Path("/tmp/pod_id").write_text(str(pod)); Path("/tmp/pod_created_epoch").write_text(str(int(time.time())))
sel=json.load(open(".github/runpod-control/aqlevon-27b-r0-live-selection-20260926.json"))
out={
  "authorization_id":"AQLEVON-27B-R0-GENE1-RUNPOD-20260926-01",
  "authorization_sha256":"469dca1993c7d5c04a91f98f05688642067bc52c895eae7a36630b2f62d81b8a",
  "source_sha":"__SOURCE_SHA__",
  "pod_id":pod,"created_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
  "single_use_consumed":True,"training_authorized":True,**sel
}
out["source_sha"]=Path("/tmp/source_sha").read_text().strip()
Path(".github/runpod-control/aqlevon-27b-r0-consumed-20260926.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
print("AQLEVON_27B_POD_CREATED",pod)
PY
pod="$(cat /tmp/pod_id)"

git config user.name aqlevon-runpod-bot
git config user.email actions@users.noreply.github.com
git add "$CONSUMED" "$LIVE"
git commit -m "ops: consume AQLEVON 27B authorization [skip ci]"
git fetch origin ops/aqlevon-27b-r0-20260926
git rebase origin/ops/aqlevon-27b-r0-20260926 || { git rebase --abort || true; exit 1; }
git push origin HEAD:ops/aqlevon-27b-r0-20260926

proxy="https://$pod-8000.proxy.runpod.net"
maxsecs="$(python3 -c 'import json;print(json.load(open(".github/runpod-control/aqlevon-27b-r0-live-selection-20260926.json"))["dynamic_max_billed_seconds"])')"
http_seen=0
final_stage=""
last_ok_epoch=0
for i in $(seq 1 2000); do
  now="$(date +%s)"
  elapsed=$(( now - $(cat /tmp/pod_created_epoch) ))
  if curl -fsS --connect-timeout 5 --max-time 10 "$proxy/status.json?t=$now" -o /tmp/status.json 2>/dev/null; then
    http_seen=1; last_ok_epoch="$now"
    stage="$(python3 - <<'PY'
import json
try: print(json.load(open("/tmp/status.json")).get("stage",""))
except Exception: print("")
PY
)"
    echo "AQLEVON_27B_HTTP_STATUS elapsed=$elapsed stage=$stage"
    case "$stage" in DONE|FAILED) final_stage="$stage"; break;; esac
  elif [ "$http_seen" = 1 ] && [ "$last_ok_epoch" -gt 0 ] && [ $((now-last_ok_epoch)) -gt 180 ]; then
    final_stage="HTTP_LOST"; break
  fi
  if [ "$http_seen" = 0 ] && [ "$elapsed" -ge 600 ]; then final_stage="HTTP_READINESS_TIMEOUT"; break; fi
  if [ "$elapsed" -ge $((maxsecs-180)) ]; then final_stage="BILLING_WINDOW_TIMEOUT"; break; fi
  sleep 10
done
printf '%s\n' "$final_stage" >/tmp/final_stage

if [ "$final_stage" = "DONE" ] || [ "$final_stage" = "FAILED" ]; then
  curl -fsS --connect-timeout 10 --max-time 240 "$proxy/evidence.tgz" -o /tmp/evidence.tgz || true
fi

# Always stop and delete exact Pod before final science receipt.
curl -sS -X POST "https://rest.runpod.io/v1/pods/$pod/stop" \
  -H "Authorization: Bearer $RUNPOD_API_KEY" -H 'Content-Type: application/json' -d '{}' >/tmp/stop.json || true
for i in $(seq 1 45); do
  sleep 2
  code="$(curl -sS -o /tmp/stop-probe.json -w '%{http_code}' "https://rest.runpod.io/v1/pods/$pod" -H "Authorization: Bearer $RUNPOD_API_KEY" || true)"
  [ "$code" = 404 ] && break
  python3 -c 'import json,sys;p=json.load(open("/tmp/stop-probe.json"));sys.exit(0 if p.get("desiredStatus")=="EXITED" else 1)' && break || true
done
curl -sS -X DELETE "https://rest.runpod.io/v1/pods/$pod" -H "Authorization: Bearer $RUNPOD_API_KEY" >/tmp/delete.json || true
for i in $(seq 1 45); do
  code="$(curl -sS -o /tmp/final-pod.json -w '%{http_code}' "https://rest.runpod.io/v1/pods/$pod" -H "Authorization: Bearer $RUNPOD_API_KEY" || true)"
  if [ "$code" = 404 ]; then cleaned=1; break; fi
  sleep 2
done
test "$cleaned" = 1

python3 - <<'PY'
import datetime,hashlib,json,tarfile
from pathlib import Path
def txt(p): return Path(p).read_text().strip() if Path(p).exists() else None
start=int(txt("/tmp/pod_created_epoch"))
elapsed=int(datetime.datetime.now(datetime.timezone.utc).timestamp())-start
sel=json.load(open(".github/runpod-control/aqlevon-27b-r0-live-selection-20260926.json"))
stage=txt("/tmp/final_stage")
status={}
if Path("/tmp/status.json").exists():
    try: status=json.loads(Path("/tmp/status.json").read_text())
    except Exception: pass
cost=round(float(sel["selected_price_hr"])*elapsed/3600,6)
out={
  "kind":"AQLEVON_27B_R0_RUN_RECEIPT_V1",
  "authorization_id":"AQLEVON-27B-R0-GENE1-RUNPOD-20260926-01",
  "authorization_sha256":"469dca1993c7d5c04a91f98f05688642067bc52c895eae7a36630b2f62d81b8a",
  "source_sha":txt("/tmp/source_sha"),"pod_id":txt("/tmp/pod_id"),
  "checked_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
  "final_transport_stage":stage,"http_status":status,
  "rate_per_hour_usd":sel.get("selected_price_hr"),"billed_seconds_estimate":elapsed,
  "compute_cost_estimate_usd":cost,"authorized_compute_cap_usd":7.20,
  "mission_budget_usd":8.00,"pod_stopped_and_deleted":True,
  "single_use_consumed":True,"sealed_eval_consumed":False,
  "worker05_used_for_tuning":False,"capability_gain_claim":False,
  "evidence_archive_present":Path("/tmp/evidence.tgz").exists(),
  "evidence_archive_sha256":hashlib.sha256(Path("/tmp/evidence.tgz").read_bytes()).hexdigest() if Path("/tmp/evidence.tgz").exists() else None
}
if Path("/tmp/evidence.tgz").exists():
    try:
        with tarfile.open("/tmp/evidence.tgz","r:gz") as t:
            man=json.loads(t.extractfile("candidate/candidate_artifact_manifest.json").read())
            rec=json.loads(t.extractfile("candidate/training_run_receipt.json").read())
        out.update({
          "candidate_status":man.get("candidate_status"),"model_name":man.get("model_name"),
          "manifest_sha256":man.get("manifest_sha256"),"adapter_model_sha256":man.get("adapter_model_sha256"),
          "optimizer_updates":rec.get("optimizer_updates"),
          "dev_pre_successes":rec.get("dev_pre_successes"),"dev_post_successes":rec.get("dev_post_successes"),
          "shadow_pre_successes":rec.get("shadow_pre_successes"),"shadow_post_successes":rec.get("shadow_post_successes"),
          "public_retention_gate_pass":rec.get("public_retention_gate_pass"),
          "public_gain_observed":rec.get("public_gain_observed")
        })
    except Exception as e: out["artifact_parse_error"]=repr(e)
Path(".github/runpod-control/aqlevon-27b-r0-run-result-20260926.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
print("AQLEVON_27B_RESULT",json.dumps(out,sort_keys=True))
PY

git add "$RESULT"
git commit -m "ops: record AQLEVON 27B run result [skip ci]" || true
git fetch origin ops/aqlevon-27b-r0-20260926
git rebase origin/ops/aqlevon-27b-r0-20260926 || { git rebase --abort || true; exit 1; }
git push origin HEAD:ops/aqlevon-27b-r0-20260926
trap - EXIT
