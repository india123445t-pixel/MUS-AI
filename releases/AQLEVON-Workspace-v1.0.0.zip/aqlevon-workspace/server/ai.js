// ---------------------------------------------------------------
// AQLEVON sovereign runtime layer.
//
// There is exactly ONE inference identity in the product: AQLEVON.
// The browser never chooses a provider, model ID, endpoint, or API key.
// Runtime configuration is operator-side only:
//   AQLEVON_MODEL_URL   OpenAI-compatible base URL or /chat/completions URL
//   AQLEVON_MODEL_NAME  served model name (default: AQLEVON-27B)
//   AQLEVON_MODEL_KEY   optional bearer token for a private endpoint
//
// No external-model fallback exists here. If AQLEVON is unavailable the
// request fails closed with a typed `aqlevon_unavailable` error.
// ---------------------------------------------------------------

const AI_TIMEOUT_MS = Number(process.env.AQLEVON_TIMEOUT_MS || process.env.AI_TIMEOUT_MS || 60000);
const DEFAULT_BASE_URL = 'http://127.0.0.1:8000/v1';
const DEFAULT_MODEL = 'AQLEVON-27B';

function normalizeChatUrl(value) {
  let url = String(value || DEFAULT_BASE_URL).trim().replace(/\/+$/, '');
  if (!url) url = DEFAULT_BASE_URL;
  if (/\/chat\/completions$/i.test(url)) return url;
  return url + '/chat/completions';
}

export function providerConfig() {
  return {
    provider: 'aqlevon',
    apiKey: process.env.AQLEVON_MODEL_KEY || '',
    model: process.env.AQLEVON_MODEL_NAME || DEFAULT_MODEL,
    baseUrl: process.env.AQLEVON_MODEL_URL || DEFAULT_BASE_URL,
  };
}

export function defaultModel() {
  return providerConfig().model;
}

export function runtimeDescriptor() {
  const cfg = providerConfig();
  return {
    provider: 'aqlevon',
    model: cfg.model,
    mode: 'self_hosted_only',
    auth: cfg.apiKey ? 'private-bearer' : 'local-or-network',
    configured: true,
  };
}

// Configuration is built into the product. This means "configured", not that
// the runtime is currently reachable; reachability is discovered on inference.
export function isConfigured() {
  return true;
}

// The public/client contract never selects another model. `requested` is
// intentionally ignored so legacy clients cannot bypass the sovereign runtime.
export function routeModel(_requested, needs = {}) {
  if (needs.vision && process.env.AQLEVON_VISION_ENABLED !== 'true') {
    const err = new Error('AQLEVON vision is not enabled on this runtime.');
    err.code = 'no_compatible_model';
    throw err;
  }
  return defaultModel();
}

function prepMessages(messages, reasoning) {
  const sysExtra = reasoning === 'extended'
    ? '\nUse additional reasoning effort. Verify important assumptions before answering.' : '';
  const msgs = messages.map(m => ({ ...m }));
  if (sysExtra) {
    if (msgs[0]?.role === 'system') msgs[0].content += sysExtra;
    else msgs.unshift({ role: 'system', content: 'You are AQLEVON.' + sysExtra });
  }
  return msgs;
}

function runtimeError(message, cause) {
  const err = new Error(message);
  err.code = 'aqlevon_unavailable';
  if (cause) err.cause = cause;
  return err;
}

async function doFetch(url, opts, signal) {
  const timeoutSignal = AbortSignal.timeout(AI_TIMEOUT_MS);
  const combined = signal ? AbortSignal.any([signal, timeoutSignal]) : timeoutSignal;
  try {
    return await fetch(url, { ...opts, signal: combined });
  } catch (e) {
    if (signal?.aborted) {
      const err = new Error('cancelled');
      err.code = 'cancelled';
      throw err;
    }
    if (e.name === 'TimeoutError' || e.name === 'AbortError') {
      throw runtimeError(`AQLEVON timed out after ${AI_TIMEOUT_MS / 1000}s`, e);
    }
    throw runtimeError('AQLEVON runtime is unreachable.', e);
  }
}

function requestHeaders(cfg) {
  return {
    'Content-Type': 'application/json',
    ...(cfg.apiKey ? { Authorization: `Bearer ${cfg.apiKey}` } : {}),
  };
}

function requestBody(cfg, messages, { stream = false } = {}) {
  return {
    model: cfg.model,
    messages,
    ...(stream ? { stream: true, stream_options: { include_usage: true } } : {}),
  };
}

export async function complete(messages, { reasoning = 'standard', signal } = {}) {
  const r = await completeFull(messages, { reasoning, signal });
  return r.text;
}

export async function completeFull(messages, { reasoning = 'standard', signal } = {}) {
  const cfg = providerConfig();
  const msgs = prepMessages(messages, reasoning);
  const r = await doFetch(normalizeChatUrl(cfg.baseUrl), {
    method: 'POST',
    headers: requestHeaders(cfg),
    body: JSON.stringify(requestBody(cfg, msgs)),
  }, signal);
  if (!r.ok) {
    const detail = (await r.text()).slice(0, 300);
    throw runtimeError(`AQLEVON runtime returned HTTP ${r.status}${detail ? ': ' + detail : ''}`);
  }
  let j;
  try { j = await r.json(); }
  catch (e) { throw runtimeError('AQLEVON returned an invalid response.', e); }
  const u = j.usage;
  return {
    text: j.choices?.[0]?.message?.content || '',
    model: cfg.model,
    usage: u ? { prompt: u.prompt_tokens, completion: u.completion_tokens, total: u.total_tokens } : null,
  };
}

// Streaming OpenAI-compatible chat completions. The served model identity is
// always normalized to AQLEVON_MODEL_NAME even if an upstream engine reports its
// internal checkpoint name; public product identity must remain AQLEVON.
export async function completeStream(messages, { reasoning = 'standard', signal, onDelta } = {}) {
  const cfg = providerConfig();
  const msgs = prepMessages(messages, reasoning);
  const r = await doFetch(normalizeChatUrl(cfg.baseUrl), {
    method: 'POST',
    headers: requestHeaders(cfg),
    body: JSON.stringify(requestBody(cfg, msgs, { stream: true })),
  }, signal);
  if (!r.ok) {
    const detail = (await r.text()).slice(0, 300);
    throw runtimeError(`AQLEVON runtime returned HTTP ${r.status}${detail ? ': ' + detail : ''}`);
  }

  let full = '', usage = null;
  for await (const data of sseLines(r.body, signal)) {
    if (data === '[DONE]') break;
    try {
      const j = JSON.parse(data);
      const t = j.choices?.[0]?.delta?.content || '';
      if (t) { full += t; onDelta?.(t); }
      if (j.usage) usage = {
        prompt: j.usage.prompt_tokens,
        completion: j.usage.completion_tokens,
        total: j.usage.total_tokens,
      };
    } catch { /* keepalive / partial frame */ }
  }
  return { text: full, model: cfg.model, usage };
}

async function* sseLines(body, signal) {
  const decoder = new TextDecoder();
  let buf = '';
  for await (const chunk of body) {
    if (signal?.aborted) {
      const e = new Error('cancelled');
      e.code = 'cancelled';
      throw e;
    }
    buf += decoder.decode(chunk, { stream: true });
    const lines = buf.split('\n');
    buf = lines.pop();
    for (const line of lines) {
      const m = line.match(/^data:\s?(.*)$/);
      if (m) yield m[1];
    }
  }
}
