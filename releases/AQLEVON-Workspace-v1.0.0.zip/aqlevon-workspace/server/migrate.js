// Schema migrations for the Production Completion Pass.
// Idempotent: safe to run on every boot, preserves all existing data.
import { db } from './db.js';

function hasColumn(table, col) {
  return db.prepare(`PRAGMA table_info(${table})`).all().some(c => c.name === col);
}

export function migrate() {
  db.exec(`
  -- Durable job runtime -------------------------------------------------
  CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL,
    kind TEXT NOT NULL,              -- work.report | research.deep | artifact.pdf | code.task | director
    title TEXT NOT NULL,
    input TEXT NOT NULL DEFAULT '{}',-- JSON
    status TEXT NOT NULL DEFAULT 'queued',
    -- queued|running|waiting_approval|done|failed|cancelled
    progress REAL NOT NULL DEFAULT 0,
    progress_note TEXT DEFAULT '',
    result TEXT,                     -- JSON
    error TEXT,
    attempts INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 3,
    idempotency_key TEXT,
    cancel_requested INTEGER NOT NULL DEFAULT 0,
    verified INTEGER NOT NULL DEFAULT 0,
    verify_note TEXT,
    parent_id TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );
  CREATE UNIQUE INDEX IF NOT EXISTS idx_jobs_idem ON jobs(idempotency_key) WHERE idempotency_key IS NOT NULL;
  CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);

  -- Checkpointed steps: resume = skip steps already 'done' ---------------
  CREATE TABLE IF NOT EXISTS job_steps (
    job_id TEXT NOT NULL,
    step TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'done',
    output TEXT,                     -- JSON checkpoint
    updated_at TEXT NOT NULL,
    PRIMARY KEY (job_id, step)
  );

  -- Scheduler execution history ------------------------------------------
  CREATE TABLE IF NOT EXISTS schedule_runs (
    id TEXT PRIMARY KEY,
    schedule_id TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    status TEXT NOT NULL,            -- ok | failed
    detail TEXT
  );

  -- Research evidence ------------------------------------------------------
  CREATE TABLE IF NOT EXISTS evidence (
    id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL,
    url TEXT NOT NULL,
    title TEXT,
    snippet TEXT,
    fetched INTEGER NOT NULL DEFAULT 0,
    content TEXT,
    created_at TEXT NOT NULL
  );

  -- Plugin credentials / permissions ---------------------------------------
  CREATE TABLE IF NOT EXISTS credentials (
    plugin_id TEXT PRIMARY KEY,
    kind TEXT NOT NULL DEFAULT 'token',   -- token | oauth
    secret TEXT,                          -- server-side only, NEVER sent to client
    scopes TEXT NOT NULL DEFAULT '[]',    -- JSON array: READ/CREATE/UPDATE/DELETE/SEND/PUBLISH
    status TEXT NOT NULL DEFAULT 'disconnected', -- connected | disconnected | error
    updated_at TEXT
  );

  -- Developer checkpoints ----------------------------------------------------
  CREATE TABLE IF NOT EXISTS checkpoints (
    id TEXT PRIMARY KEY,
    repo TEXT NOT NULL,
    label TEXT,
    git_ref TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
  `);

  // scheduled: add columns needed by the real scheduler
  if (!hasColumn('scheduled', 'next_run')) db.exec(`ALTER TABLE scheduled ADD COLUMN next_run TEXT`);
  if (!hasColumn('scheduled', 'timezone')) db.exec(`ALTER TABLE scheduled ADD COLUMN timezone TEXT DEFAULT 'Africa/Casablanca'`);
  if (!hasColumn('scheduled', 'interval_minutes')) db.exec(`ALTER TABLE scheduled ADD COLUMN interval_minutes INTEGER`);
  if (!hasColumn('scheduled', 'condition_query')) db.exec(`ALTER TABLE scheduled ADD COLUMN condition_query TEXT`);

  // chats: track which model actually answered
  if (!hasColumn('messages', 'model')) db.exec(`ALTER TABLE messages ADD COLUMN model TEXT`);
  if (!hasColumn('messages', 'usage')) db.exec(`ALTER TABLE messages ADD COLUMN usage TEXT`);

  // chats: pinning for the sidebar (defect-driven additive change; default 0)
  if (!hasColumn('chats', 'pinned')) db.exec(`ALTER TABLE chats ADD COLUMN pinned INTEGER DEFAULT 0`);
}
