import express from 'express';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import { fileURLToPath } from 'url';
import { db, WS, uid, now, UPLOAD_DIR, getSetting, setSetting } from './db.js';
import { accessGuard, accessMode } from './access.js';
import { completeFull, completeStream, isConfigured, runtimeDescriptor, routeModel } from './ai.js';
import { migrate } from './migrate.js';
import { createJob, getJob, listJobs, cancelJob, retryJob, recoverJobs } from './jobs.js';
import './handlers.js';
import { startScheduler, computeNextRun } from './scheduler.js';
import { webSearch } from './search.js';
import * as dev from './devspace.js';
import * as browserAgent from './browser.js';

migrate();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({ limit: '5mb' }));

// multer decodes filenames as latin1; recover proper UTF-8 (Arabic names etc.)
function fixName(name) {
  try {
    const utf8 = Buffer.from(name, 'latin1').toString('utf8');
    // If round-trip is lossless, the original was UTF-8 mis-read as latin1.
    return Buffer.from(utf8, 'utf8').toString('latin1') === name ? utf8 : name;
  } catch { return name; }
}

const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (_req, file, cb) =>
      cb(null, uid() + '-' + fixName(file.originalname).replace(/[^\w.\u0600-\u06FF -]+/g, '_').replace(/\.\.+/g, '.'))
  }),
  limits: { fileSize: 25 * 1024 * 1024 }
});

// ---------- basic rate limiting (in-memory, per-IP) ----------
const buckets = new Map();
function rateLimit(max, windowMs) {
  return (req, res, next) => {
    const key = (req.ip || 'x') + ':' + req.baseUrl + req.path.split('/')[1];
    const nowMs = Date.now();
    let b = buckets.get(key);
    if (!b || nowMs - b.start > windowMs) { b = { start: nowMs, count: 0 }; buckets.set(key, b); }
    if (++b.count > max) return res.status(429).json({ error: 'Too many requests. Slow down.' });
    next();
  };
}
setInterval(() => {
  const cutoff = Date.now() - 120000;
  for (const [k, b] of buckets) if (b.start < cutoff) buckets.delete(k);
}, 60000).unref();

// Single access gate for the whole API (no-op when AUTH_MODE=disabled).
app.use('/api', accessGuard);
app.use('/api', rateLimit(300, 60000));               // general: 300 req/min
app.use('/api/chats/:id/messages', rateLimit(30, 60000)); // AI calls: 30/min
app.use('/api/tasks', rateLimit(30, 60000));

const wsId = WS.wsId;

// ---------- bootstrap ----------
app.get('/api/bootstrap', (_req, res) => {
  res.json({
    mode: accessMode(),
    workspace: db.prepare('SELECT id, name, created_at FROM workspaces WHERE id=?').get(wsId),
    aiConfigured: isConfigured(),
    runtime: runtimeDescriptor()
  });
});

// ---------- chats ----------
app.get('/api/chats', (req, res) => {
  const q = (req.query.q || '').trim();
  let rows;
  if (q) {
    rows = db.prepare(`
      SELECT DISTINCT c.* FROM chats c
      LEFT JOIN messages m ON m.chat_id = c.id
      WHERE c.workspace_id=? AND c.temporary=0 AND (c.title LIKE ? OR m.content LIKE ?)
      ORDER BY c.updated_at DESC LIMIT 100
    `).all(wsId, `%${q}%`, `%${q}%`);
  } else {
    rows = db.prepare(
      'SELECT * FROM chats WHERE workspace_id=? AND temporary=0 AND project_id IS NULL ORDER BY updated_at DESC LIMIT 100'
    ).all(wsId);
  }
  res.json(rows);
});

app.post('/api/chats', (req, res) => {
  const id = uid();
  const t = now();
  db.prepare('INSERT INTO chats (id, workspace_id, project_id, title, temporary, created_at, updated_at) VALUES (?,?,?,?,?,?,?)')
    .run(id, wsId, req.body.projectId || null, req.body.title || 'New chat', req.body.temporary ? 1 : 0, t, t);
  res.json(db.prepare('SELECT * FROM chats WHERE id=?').get(id));
});

app.get('/api/chats/:id', (req, res) => {
  const chat = db.prepare('SELECT * FROM chats WHERE id=? AND workspace_id=?').get(req.params.id, wsId);
  if (!chat) return res.status(404).json({ error: 'not found' });
  const messages = db.prepare('SELECT * FROM messages WHERE chat_id=? ORDER BY created_at, rowid').all(chat.id);
  res.json({ ...chat, messages });
});

app.patch('/api/chats/:id', (req, res) => {
  if (req.body.title !== undefined)
    db.prepare('UPDATE chats SET title=?, updated_at=? WHERE id=? AND workspace_id=?')
      .run(req.body.title, now(), req.params.id, wsId);
  if (req.body.pinned !== undefined)
    db.prepare('UPDATE chats SET pinned=? WHERE id=? AND workspace_id=?')
      .run(req.body.pinned ? 1 : 0, req.params.id, wsId);
  res.json({ ok: true });
});

app.delete('/api/chats/:id', (req, res) => {
  db.prepare('DELETE FROM messages WHERE chat_id=?').run(req.params.id);
  db.prepare('DELETE FROM chats WHERE id=? AND workspace_id=?').run(req.params.id, wsId);
  res.json({ ok: true });
});

// Branch: copy chat + messages up to a message id
app.post('/api/chats/:id/branch', (req, res) => {
  const src = db.prepare('SELECT * FROM chats WHERE id=? AND workspace_id=?').get(req.params.id, wsId);
  if (!src) return res.status(404).json({ error: 'not found' });
  const msgs = db.prepare('SELECT * FROM messages WHERE chat_id=? ORDER BY created_at, rowid').all(src.id);
  const upTo = req.body.messageId;
  const idx = upTo ? msgs.findIndex(m => m.id === upTo) : msgs.length - 1;
  const keep = msgs.slice(0, idx + 1);
  const id = uid(); const t = now();
  db.prepare('INSERT INTO chats (id, workspace_id, project_id, title, temporary, created_at, updated_at) VALUES (?,?,?,?,0,?,?)')
    .run(id, wsId, src.project_id, src.title + ' (branch)', t, t);
  const ins = db.prepare('INSERT INTO messages (id, chat_id, role, content, created_at) VALUES (?,?,?,?,?)');
  keep.forEach(m => ins.run(uid(), id, m.role, m.content, m.created_at));
  res.json({ id });
});

// ---------- messaging ----------
function buildContext(chat) {
  const sysParts = ['You are AQLEVON, the built-in AI of the user\'s personal workspace. Format answers in Markdown.'];
  if (chat.project_id) {
    const p = db.prepare('SELECT * FROM projects WHERE id=?').get(chat.project_id);
    if (p?.instructions) sysParts.push('Project instructions:\n' + p.instructions);
  }
  const mem = db.prepare('SELECT content FROM memory WHERE workspace_id=? ORDER BY created_at DESC LIMIT 20').all(wsId);
  if (mem.length) sysParts.push('Things to remember about the user:\n- ' + mem.map(m => m.content).join('\n- '));
  const custom = getSetting('personalization', '');
  if (custom) sysParts.push('User personalization:\n' + custom);
  return { role: 'system', content: sysParts.join('\n\n') };
}

// Prepare chat mutation shared by JSON + streaming endpoints.
function prepareTurn(chat, { content, regenerate, editMessageId }) {
  if (editMessageId) {
    const msgs = db.prepare('SELECT id FROM messages WHERE chat_id=? ORDER BY created_at, rowid').all(chat.id);
    const idx = msgs.findIndex(m => m.id === editMessageId);
    if (idx >= 0) {
      const del = db.prepare('DELETE FROM messages WHERE id=?');
      msgs.slice(idx).forEach(m => del.run(m.id));
    }
  }
  if (regenerate) {
    const last = db.prepare(
      "SELECT id FROM messages WHERE chat_id=? AND role='assistant' ORDER BY created_at DESC, rowid DESC LIMIT 1"
    ).get(chat.id);
    if (last) db.prepare('DELETE FROM messages WHERE id=?').run(last.id);
  }
  if (content) {
    db.prepare('INSERT INTO messages (id, chat_id, role, content, created_at) VALUES (?,?,?,?,?)')
      .run(uid(), chat.id, 'user', content, now());
  }
  const history = db.prepare('SELECT role, content FROM messages WHERE chat_id=? ORDER BY created_at, rowid').all(chat.id);
  return [buildContext(chat), ...history];
}

// Real web search context: runs an actual search and injects results w/ URLs.
async function searchContext(query) {
  const { results, engine, errors } = await webSearch(query, { limit: 5 });
  if (!results.length) return { block: null, meta: { engine: null, errors } };
  const block = 'Live web search results (engine: ' + engine + '). Cite sources by URL when you use them:\n' +
    results.map((r, i) => `[${i + 1}] ${r.title} — ${r.url}\n${r.snippet?.slice(0, 300) || ''}`).join('\n');
  return { block, meta: { engine, count: results.length, errors, sources: results.map(r => ({ title: r.title, url: r.url })) } };
}

function finishTurn(chat, reply, meta = {}) {
  const mid = uid();
  db.prepare('INSERT INTO messages (id, chat_id, role, content, created_at, model, usage) VALUES (?,?,?,?,?,?,?)')
    .run(mid, chat.id, 'assistant', reply, now(), meta.model || null, meta.usage ? JSON.stringify(meta.usage) : null);
  const firstUser = db.prepare("SELECT content FROM messages WHERE chat_id=? AND role='user' ORDER BY created_at, rowid LIMIT 1").get(chat.id);
  if (chat.title === 'New chat' && firstUser) {
    db.prepare('UPDATE chats SET title=? WHERE id=?').run(firstUser.content.split('\n')[0].slice(0, 48), chat.id);
  }
  db.prepare('UPDATE chats SET updated_at=? WHERE id=?').run(now(), chat.id);
  return mid;
}

// STREAMING endpoint (SSE). Stop generation is DETERMINISTIC: the client calls
// POST /api/chats/:id/stream/stop (below) and keeps reading this stream; the
// server aborts the AQLEVON runtime call, persists the partial text, and only
// then emits the final `done` event — so a client that refetches on `done` is
// guaranteed to see the persisted partial. Socket close still aborts too
// (tab closed), so nothing is lost either way.
const activeStreams = new Map(); // chat id -> AbortController of in-flight stream
// Test-only hook (never set in production): artificially delays partial-message
// persistence after a stop, to prove the client waits for the persist
// acknowledgement instead of relying on a fixed timeout.
const TEST_STOP_PERSIST_DELAY = Number(process.env.AQLEVON_TEST_STOP_PERSIST_DELAY_MS || process.env.KITE_TEST_STOP_PERSIST_DELAY_MS || 0);

app.post('/api/chats/:id/stream/stop', (req, res) => {
  const a = activeStreams.get(req.params.id);
  if (a) { a.userStop = true; a.abort(); }
  res.json({ stopping: Boolean(a) });
});

app.post('/api/chats/:id/stream', async (req, res) => {
  const chat = db.prepare('SELECT * FROM chats WHERE id=? AND workspace_id=?').get(req.params.id, wsId);
  if (!chat) return res.status(404).json({ error: 'not found' });
  const { content, reasoning, regenerate, editMessageId, useWebSearch, needsVision } = req.body;

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();
  const send = (ev, data) => res.write(`event: ${ev}\ndata: ${JSON.stringify(data)}\n\n`);

  const abort = new AbortController();
  activeStreams.set(chat.id, abort);
  // Socket close (tab closed / network drop) still aborts the upstream call.
  // (req 'close' fires as soon as the request body is consumed in modern
  //  Node, which would cancel every stream immediately — real bug found in testing.)
  res.on('close', () => { if (!res.writableEnded) abort.abort(); });

  let acc = ''; // accumulated text, visible to catch for partial persistence
  try {
    const context = prepareTurn(chat, { content, regenerate, editMessageId });
    if (useWebSearch && content) {
      send('status', { note: 'Searching the web…' });
      const sc = await searchContext(content);
      if (sc.block) {
        context.splice(1, 0, { role: 'system', content: sc.block });
        send('sources', sc.meta);
      } else {
        send('status', { note: 'Web search returned no results (' + JSON.stringify(sc.meta.errors).slice(0, 120) + ')' });
      }
    }
    routeModel(undefined, { vision: Boolean(needsVision) }); // capability gate only; AQLEVON model identity is fixed server-side

    const r = await completeStream(context, {
      reasoning, signal: abort.signal,
      onDelta: (t) => { acc += t; send('delta', { t }); }
    });
    const mid = finishTurn(chat, r.text || acc, { model: r.model, usage: r.usage });
    send('done', { messageId: mid, model: r.model, usage: r.usage, title: db.prepare('SELECT title FROM chats WHERE id=?').get(chat.id).title });
  } catch (e) {
    if (e.code === 'cancelled' || abort.signal.aborted) {
      // Persist whatever streamed before the stop, THEN acknowledge with the
      // final `done` event — the client refetches only after receiving it, so
      // the stopped partial is always included (no timing assumptions).
      if (TEST_STOP_PERSIST_DELAY > 0 && abort.userStop) await new Promise(r => setTimeout(r, TEST_STOP_PERSIST_DELAY));
      const mid = finishTurn(chat, (acc ? acc + ' …' : '_(stopped)_'), {});
      try { send('done', { stopped: true, messageId: mid }); } catch {}
    } else if (e.code === 'aqlevon_unavailable') {
      const msg = 'AQLEVON is temporarily unavailable. Please try again.';
      finishTurn(chat, msg, {});
      try { send('delta', { t: msg }); send('done', { error: 'aqlevon_unavailable' }); } catch {}
    } else {
      const msg = 'AQLEVON could not complete this request.';
      finishTurn(chat, msg, {});
      console.error('[aqlevon inference]', e?.message || e);
      try { send('delta', { t: msg }); send('done', { error: 'aqlevon_error' }); } catch {}
    }
  } finally {
    if (activeStreams.get(chat.id) === abort) activeStreams.delete(chat.id);
    res.end();
  }
});

app.post('/api/chats/:id/messages', async (req, res) => {
  const chat = db.prepare('SELECT * FROM chats WHERE id=? AND workspace_id=?').get(req.params.id, wsId);
  if (!chat) return res.status(404).json({ error: 'not found' });
  const { content, reasoning, regenerate, editMessageId } = req.body;

  // Edit: truncate history after (and including) the edited user message
  if (editMessageId) {
    const msgs = db.prepare('SELECT id FROM messages WHERE chat_id=? ORDER BY created_at, rowid').all(chat.id);
    const idx = msgs.findIndex(m => m.id === editMessageId);
    if (idx >= 0) {
      const drop = msgs.slice(idx).map(m => m.id);
      const del = db.prepare('DELETE FROM messages WHERE id=?');
      drop.forEach(i => del.run(i));
    }
  }
  // Regenerate: drop the last assistant message
  if (regenerate) {
    const last = db.prepare(
      "SELECT id FROM messages WHERE chat_id=? AND role='assistant' ORDER BY created_at DESC, rowid DESC LIMIT 1"
    ).get(chat.id);
    if (last) db.prepare('DELETE FROM messages WHERE id=?').run(last.id);
  }

  if (content) {
    db.prepare('INSERT INTO messages (id, chat_id, role, content, created_at) VALUES (?,?,?,?,?)')
      .run(uid(), chat.id, 'user', content, now());
  }

  const history = db.prepare('SELECT role, content FROM messages WHERE chat_id=? ORDER BY created_at, rowid').all(chat.id);
  const context = [buildContext(chat), ...history];

  let reply, error = null, meta = {};
  try {
    const r = await completeFull(context, { reasoning });
    reply = r.text; meta = { model: r.model, usage: r.usage };
  } catch (e) {
    if (e.code === 'aqlevon_unavailable') {
      reply = 'AQLEVON is temporarily unavailable. Please try again.';
      error = 'aqlevon_unavailable';
    } else {
      reply = 'AQLEVON could not complete this request.';
      error = 'aqlevon_error';
      console.error('[aqlevon inference]', e?.message || e);
    }
  }

  finishTurn(chat, reply, meta);

  const messages = db.prepare('SELECT * FROM messages WHERE chat_id=? ORDER BY created_at, rowid').all(chat.id);
  res.json({ messages, error, title: db.prepare('SELECT title FROM chats WHERE id=?').get(chat.id).title });
});

// ---------- projects ----------
app.get('/api/projects', (_req, res) => {
  const rows = db.prepare('SELECT * FROM projects WHERE workspace_id=? ORDER BY created_at DESC').all(wsId);
  res.json(rows.map(p => ({
    ...p,
    chatCount: db.prepare('SELECT COUNT(*) c FROM chats WHERE project_id=?').get(p.id).c,
    fileCount: db.prepare('SELECT COUNT(*) c FROM files WHERE project_id=?').get(p.id).c
  })));
});
app.post('/api/projects', (req, res) => {
  const id = uid();
  db.prepare('INSERT INTO projects (id, workspace_id, name, instructions, created_at) VALUES (?,?,?,?,?)')
    .run(id, wsId, req.body.name || 'Untitled project', req.body.instructions || '', now());
  res.json(db.prepare('SELECT * FROM projects WHERE id=?').get(id));
});
app.get('/api/projects/:id', (req, res) => {
  const p = db.prepare('SELECT * FROM projects WHERE id=? AND workspace_id=?').get(req.params.id, wsId);
  if (!p) return res.status(404).json({ error: 'not found' });
  res.json({
    ...p,
    chats: db.prepare('SELECT * FROM chats WHERE project_id=? ORDER BY updated_at DESC').all(p.id),
    files: db.prepare('SELECT * FROM files WHERE project_id=? ORDER BY created_at DESC').all(p.id)
  });
});
app.patch('/api/projects/:id', (req, res) => {
  const p = db.prepare('SELECT * FROM projects WHERE id=? AND workspace_id=?').get(req.params.id, wsId);
  if (!p) return res.status(404).json({ error: 'not found' });
  db.prepare('UPDATE projects SET name=?, instructions=? WHERE id=?')
    .run(req.body.name ?? p.name, req.body.instructions ?? p.instructions, p.id);
  res.json({ ok: true });
});
app.delete('/api/projects/:id', (req, res) => {
  db.prepare('UPDATE chats SET project_id=NULL WHERE project_id=?').run(req.params.id);
  db.prepare('UPDATE files SET project_id=NULL WHERE project_id=?').run(req.params.id);
  db.prepare('DELETE FROM projects WHERE id=? AND workspace_id=?').run(req.params.id, wsId);
  res.json({ ok: true });
});

// ---------- files / library ----------
app.get('/api/files', (req, res) => {
  const { q, kind } = req.query;
  let sql = 'SELECT * FROM files WHERE workspace_id=?';
  const args = [wsId];
  if (kind && kind !== 'all') { sql += ' AND kind=?'; args.push(kind); }
  if (q) { sql += ' AND name LIKE ?'; args.push(`%${q}%`); }
  sql += ' ORDER BY created_at DESC LIMIT 200';
  res.json(db.prepare(sql).all(...args));
});

app.post('/api/files', upload.single('file'), (req, res) => {
  const f = req.file;
  if (!f) return res.status(400).json({ error: 'no file' });
  const id = uid();
  const kind = (f.mimetype || '').startsWith('image/') ? 'image' : 'uploaded';
  db.prepare('INSERT INTO files (id, workspace_id, project_id, name, mime, size, kind, stored_name, created_at) VALUES (?,?,?,?,?,?,?,?,?)')
    .run(id, wsId, req.body.projectId || null, fixName(f.originalname), f.mimetype, f.size, kind, f.filename, now());
  res.json(db.prepare('SELECT * FROM files WHERE id=?').get(id));
});

app.get('/api/files/:id/content', (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id=? AND workspace_id=?').get(req.params.id, wsId);
  if (!f) return res.status(404).end();
  res.setHeader('Content-Type', f.mime || 'application/octet-stream');
  res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(f.name)}"`);
  fs.createReadStream(path.join(UPLOAD_DIR, f.stored_name)).pipe(res);
});

app.patch('/api/files/:id', (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id=? AND workspace_id=?').get(req.params.id, wsId);
  if (!f) return res.status(404).json({ error: 'Not found' });
  const name = String(req.body.name || '').trim();
  if (!name || name.length > 255 || /[/\\]/.test(name)) return res.status(400).json({ error: 'invalid name' });
  db.prepare('UPDATE files SET name=? WHERE id=?').run(name, f.id);
  res.json(db.prepare('SELECT * FROM files WHERE id=?').get(f.id));
});

app.delete('/api/files/:id', (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id=? AND workspace_id=?').get(req.params.id, wsId);
  if (f) {
    try { fs.unlinkSync(path.join(UPLOAD_DIR, f.stored_name)); } catch {}
    db.prepare('DELETE FROM files WHERE id=?').run(f.id);
  }
  res.json({ ok: true });
});

// ---------- durable jobs (Work / Research / Director) ----------
app.get('/api/jobs', (_req, res) => res.json(listJobs(wsId)));
app.get('/api/jobs/:id', (req, res) => {
  const j = getJob(req.params.id);
  if (!j || j.workspace_id !== wsId) return res.status(404).json({ error: 'not found' });
  const steps = db.prepare('SELECT step, status, updated_at FROM job_steps WHERE job_id=?').all(j.id);
  const evidence = db.prepare('SELECT url, title, fetched FROM evidence WHERE job_id=?').all(j.id);
  res.json({ ...j, steps, evidence });
});
app.post('/api/jobs', (req, res) => {
  const { kind = 'work.deliverable', title, prompt, format = 'md', question, goal, projectId, idempotencyKey } = req.body;
  let input;
  if (kind === 'research.deep') input = { question: question || prompt, iterations: Math.min(Number(req.body.iterations) || 3, 5), projectId };
  else if (kind === 'director') input = { goal: goal || prompt };
  else input = { prompt, format, title: title || 'deliverable', projectId, kind: req.body.deliverableKind || 'report' };
  const job = createJob({ kind, title: title || (prompt || question || goal || 'Task').slice(0, 60), input, workspaceId: wsId, idempotencyKey: idempotencyKey || null });
  res.json(job);
});
app.post('/api/jobs/:id/cancel', (req, res) => res.json(cancelJob(req.params.id)));
app.post('/api/jobs/:id/retry', (req, res) => res.json(retryJob(req.params.id)));
app.delete('/api/jobs/:id', (req, res) => {
  db.prepare('DELETE FROM job_steps WHERE job_id=?').run(req.params.id);
  db.prepare('DELETE FROM evidence WHERE job_id=?').run(req.params.id);
  db.prepare('DELETE FROM jobs WHERE id=? AND workspace_id=?').run(req.params.id, wsId);
  res.json({ ok: true });
});

// Legacy /api/tasks kept as a thin alias over jobs (backward compat)
app.get('/api/tasks', (_req, res) => {
  res.json(listJobs(wsId).map(j => ({
    id: j.id, title: j.title, kind: j.kind, prompt: JSON.parse(j.input||'{}').prompt || JSON.parse(j.input||'{}').question || '',
    status: j.status, error: j.error, created_at: j.created_at,
    result_file_id: j.result ? (JSON.parse(j.result)?.fileId || null) : null,
    progress: j.progress, progress_note: j.progress_note
  })));
});
app.post('/api/tasks', (req, res) => {
  const job = createJob({ kind: 'work.deliverable', title: req.body.title || 'Untitled task',
    input: { prompt: req.body.prompt || '', format: req.body.format || 'md', title: req.body.title || 'deliverable', kind: req.body.kind || 'report', projectId: req.body.projectId || null },
    workspaceId: wsId });
  res.json({ id: job.id, status: job.status });
});
app.post('/api/tasks/:id/retry', (req, res) => res.json(retryJob(req.params.id) || { ok: true }));
app.delete('/api/tasks/:id', (req, res) => {
  db.prepare('DELETE FROM jobs WHERE id=? AND workspace_id=?').run(req.params.id, wsId);
  res.json({ ok: true });
});

// ---------- real web search API ----------
app.get('/api/search', async (req, res) => {
  const q = (req.query.q || '').trim();
  if (!q) return res.status(400).json({ error: 'missing q' });
  res.json(await webSearch(q, { limit: Math.min(Number(req.query.limit) || 8, 15) }));
});

// ---------- scheduled (real execution) ----------
app.get('/api/scheduled', (_req, res) => {
  const items = db.prepare('SELECT * FROM scheduled WHERE workspace_id=? ORDER BY created_at DESC').all(wsId);
  res.json(items.map(i => ({ ...i,
    runs: db.prepare('SELECT * FROM schedule_runs WHERE schedule_id=? ORDER BY started_at DESC LIMIT 5').all(i.id) })));
});
app.post('/api/scheduled', (req, res) => {
  const id = uid();
  const { title, kind = 'once', prompt = '', runAt, intervalMinutes, conditionQuery, timezone } = req.body;
  let nextRun = null, interval = null;
  if (kind === 'once') {
    nextRun = runAt ? new Date(runAt).toISOString() : new Date(Date.now() + 60000).toISOString();
    if (isNaN(Date.parse(nextRun))) return res.status(400).json({ error: 'invalid runAt datetime' });
  } else {
    if (!Number(intervalMinutes) || Number(intervalMinutes) < 1) {
      return res.status(400).json({ error: 'intervalMinutes (>=1) is required for recurring/monitor schedules' });
    }
    if (kind === 'monitor' && !(conditionQuery || '').trim()) {
      return res.status(400).json({ error: 'conditionQuery is required for monitor schedules' });
    }
    interval = Math.max(1, Number(intervalMinutes));
    nextRun = new Date(Date.now() + interval * 60000).toISOString();
  }
  db.prepare(`INSERT INTO scheduled (id, workspace_id, title, kind, schedule, prompt, next_run, interval_minutes, condition_query, timezone, created_at)
              VALUES (?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id, wsId, title || 'Untitled', kind, req.body.schedule || '', prompt, nextRun, interval,
         conditionQuery || null, timezone || 'Africa/Casablanca', now());
  res.json(db.prepare('SELECT * FROM scheduled WHERE id=?').get(id));
});
app.patch('/api/scheduled/:id', (req, res) => {
  const item = db.prepare('SELECT * FROM scheduled WHERE id=? AND workspace_id=?').get(req.params.id, wsId);
  if (!item) return res.status(404).json({ error: 'not found' });
  if (req.body.enabled !== undefined) {
    const en = req.body.enabled ? 1 : 0;
    let nextRun = item.next_run;
    if (en && !nextRun) nextRun = computeNextRun(item); // resume re-arms the schedule
    db.prepare('UPDATE scheduled SET enabled=?, next_run=? WHERE id=?').run(en, en ? nextRun : item.next_run, item.id);
  }
  res.json({ ok: true });
});
app.delete('/api/scheduled/:id', (req, res) => {
  db.prepare('DELETE FROM schedule_runs WHERE schedule_id=?').run(req.params.id);
  db.prepare('DELETE FROM scheduled WHERE id=? AND workspace_id=?').run(req.params.id, wsId);
  res.json({ ok: true });
});

// ---------- browser agent (sandboxed Chromium, SSRF-guarded, injection-isolated) ----------
app.get('/api/browser/sessions', (req, res) => res.json(browserAgent.listSessions()));

app.post('/api/browser/sessions', async (req, res) => {
  try { res.json(await browserAgent.createSession(String(req.body.url || ''))); }
  catch (e) { res.status(400).json({ error: e.message }); }
});

app.post('/api/browser/sessions/:id/act', async (req, res) => {
  try { res.json(await browserAgent.act(req.params.id, req.body || {})); }
  catch (e) { res.status(400).json({ error: e.message }); }
});

app.delete('/api/browser/sessions/:id', async (req, res) => {
  res.json({ closed: await browserAgent.closeSession(req.params.id) });
});

// ---------- plugins / connected apps (credentials + permissions) ----------
const PLUGIN_SCOPES = { 'github': ['READ','CREATE','UPDATE'], 'web-search': ['READ'], 'calendar': ['READ','CREATE'], 'drive': ['READ','CREATE','UPDATE','DELETE'], 'code-interpreter': ['READ'], 'image-gen': ['CREATE'] };
app.get('/api/plugins', (_req, res) => {
  const plugins = db.prepare('SELECT * FROM plugins ORDER BY name').all();
  res.json(plugins.map(p => {
    const cred = db.prepare('SELECT kind, scopes, status, updated_at FROM credentials WHERE plugin_id=?').get(p.id);
    return { ...p, availableScopes: PLUGIN_SCOPES[p.id] || ['READ'],
      connection: cred ? { kind: cred.kind, scopes: JSON.parse(cred.scopes||'[]'), status: cred.status, updated_at: cred.updated_at } : { status: 'disconnected', scopes: [] } };
  }));
});
app.patch('/api/plugins/:id', (req, res) => {
  const p = db.prepare('SELECT * FROM plugins WHERE id=?').get(req.params.id);
  if (!p) return res.status(404).json({ error: 'not found' });
  db.prepare('UPDATE plugins SET installed=?, enabled=? WHERE id=?').run(
    req.body.installed !== undefined ? (req.body.installed ? 1 : 0) : p.installed,
    req.body.enabled !== undefined ? (req.body.enabled ? 1 : 0) : p.enabled,
    p.id
  );
  res.json({ ok: true });
});
// Connect with a token (secret stays server-side; status verified where possible)
app.post('/api/plugins/:id/connect', async (req, res) => {
  const p = db.prepare('SELECT * FROM plugins WHERE id=?').get(req.params.id);
  if (!p) return res.status(404).json({ error: 'not found' });
  const { token, scopes = ['READ'] } = req.body;
  if (!token || typeof token !== 'string') return res.status(400).json({ error: 'token required' });
  const allowed = PLUGIN_SCOPES[p.id] || ['READ'];
  const granted = scopes.filter(sc => allowed.includes(sc));
  let status = 'connected', note = null;
  if (p.id === 'github') {
    try {
      const r = await fetch('https://api.github.com/user', { headers: { Authorization: 'Bearer ' + token, 'User-Agent': 'AQLEVON' }, signal: AbortSignal.timeout(8000) });
      if (!r.ok) { status = 'error'; note = 'GitHub rejected the token (HTTP ' + r.status + ')'; }
      else note = 'authenticated as ' + (await r.json()).login;
    } catch (e) { status = 'error'; note = 'could not verify token: ' + e.message; }
  }
  db.prepare(`INSERT INTO credentials (plugin_id, kind, secret, scopes, status, updated_at) VALUES (?,?,?,?,?,?)
              ON CONFLICT(plugin_id) DO UPDATE SET secret=excluded.secret, scopes=excluded.scopes, status=excluded.status, updated_at=excluded.updated_at`)
    .run(p.id, 'token', token, JSON.stringify(granted), status, now());
  if (status === 'connected') db.prepare('UPDATE plugins SET installed=1, enabled=1 WHERE id=?').run(p.id);
  res.json({ status, scopes: granted, note }); // token itself is never echoed back
});
app.post('/api/plugins/:id/disconnect', (req, res) => {
  db.prepare('DELETE FROM credentials WHERE plugin_id=?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- developer workspace (real git) ----------
app.get('/api/dev/repos', (_req, res) => res.json(dev.listRepos()));
app.post('/api/dev/repos', async (req, res) => {
  try {
    if (req.body.cloneUrl) res.json(await dev.githubClone(req.body.cloneUrl, req.body.name));
    else res.json(dev.createRepo(req.body.name));
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.get('/api/dev/repos/:repo/tree', (req, res) => {
  try { res.json(dev.fileTree(req.params.repo)); } catch (e) { res.status(400).json({ error: e.message }); }
});
app.get('/api/dev/repos/:repo/file', (req, res) => {
  try { res.json({ content: dev.readRepoFile(req.params.repo, req.query.path) }); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
app.put('/api/dev/repos/:repo/file', (req, res) => {
  try { res.json(dev.writeRepoFile(req.params.repo, req.body.path, req.body.content ?? '')); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
app.get('/api/dev/repos/:repo/status', (req, res) => {
  try { res.json(dev.gitStatus(req.params.repo)); } catch (e) { res.status(400).json({ error: e.message }); }
});
app.get('/api/dev/repos/:repo/diff', (req, res) => {
  try { res.json(dev.gitDiff(req.params.repo)); } catch (e) { res.status(400).json({ error: e.message }); }
});
app.post('/api/dev/repos/:repo/commit', (req, res) => {
  try { res.json(dev.gitCommit(req.params.repo, req.body.message)); } catch (e) { res.status(400).json({ error: e.message }); }
});
app.get('/api/dev/repos/:repo/branches', (req, res) => {
  try { res.json(dev.branches(req.params.repo)); } catch (e) { res.status(400).json({ error: e.message }); }
});
app.post('/api/dev/repos/:repo/branches', (req, res) => {
  try { res.json(dev.createBranch(req.params.repo, req.body.name)); } catch (e) { res.status(400).json({ error: e.message }); }
});
app.post('/api/dev/repos/:repo/checkout', (req, res) => {
  try { res.json(dev.checkout(req.params.repo, req.body.name)); } catch (e) { res.status(400).json({ error: e.message }); }
});
app.get('/api/dev/repos/:repo/search', (req, res) => {
  try { res.json(dev.searchRepo(req.params.repo, String(req.query.q || ''))); } catch (e) { res.status(400).json({ error: e.message }); }
});
app.post('/api/dev/repos/:repo/checkpoints', (req, res) => {
  try { res.json(dev.createCheckpoint(req.params.repo, req.body.label)); } catch (e) { res.status(400).json({ error: e.message }); }
});
app.get('/api/dev/repos/:repo/checkpoints', (req, res) => {
  try { res.json(dev.listCheckpoints(req.params.repo)); } catch (e) { res.status(400).json({ error: e.message }); }
});
app.post('/api/dev/repos/:repo/rollback', (req, res) => {
  try { res.json(dev.rollback(req.params.repo, req.body.checkpointId)); } catch (e) { res.status(400).json({ error: e.message }); }
});
app.post('/api/dev/repos/:repo/run', rateLimit(20, 60000), async (req, res) => {
  try { res.json(await dev.runSandboxed(req.params.repo, String(req.body.command || ''))); }
  catch (e) { res.status(400).json({ error: e.message }); }
});
app.get('/api/dev/github/status', (_req, res) => res.json(dev.githubStatus()));

// ---------- memory ----------
app.get('/api/memory', (_req, res) => {
  res.json(db.prepare('SELECT * FROM memory WHERE workspace_id=? ORDER BY created_at DESC').all(wsId));
});
app.post('/api/memory', (req, res) => {
  const id = uid();
  db.prepare('INSERT INTO memory (id, workspace_id, content, created_at) VALUES (?,?,?,?)')
    .run(id, wsId, req.body.content || '', now());
  res.json({ id });
});
app.delete('/api/memory/:id', (req, res) => {
  db.prepare('DELETE FROM memory WHERE id=? AND workspace_id=?').run(req.params.id, wsId);
  res.json({ ok: true });
});

// ---------- settings ----------
const SETTING_KEYS = ['theme', 'personalization', 'voice_enabled', 'notifications',
  'language', 'search_default', 'research_depth', 'timezone_default', 'density', 'startup_page'];

app.get('/api/settings', (_req, res) => {
  const out = {};
  for (const k of SETTING_KEYS) out[k] = getSetting(k, '');
  res.json(out);
});

app.post('/api/settings', (req, res) => {
  for (const k of SETTING_KEYS) {
    if (req.body[k] !== undefined) setSetting(k, req.body[k]);
  }
  // Model/provider credentials are deliberately not user-configurable.
  res.json({ ok: true });
});

// Data controls
app.post('/api/data/clear-chats', (_req, res) => {
  db.prepare('DELETE FROM messages WHERE chat_id IN (SELECT id FROM chats WHERE workspace_id=?)').run(wsId);
  db.prepare('DELETE FROM chats WHERE workspace_id=?').run(wsId);
  res.json({ ok: true });
});
app.get('/api/data/export', (_req, res) => {
  const dump = {
    chats: db.prepare('SELECT * FROM chats WHERE workspace_id=?').all(wsId),
    messages: db.prepare('SELECT m.* FROM messages m JOIN chats c ON c.id=m.chat_id WHERE c.workspace_id=?').all(wsId),
    projects: db.prepare('SELECT * FROM projects WHERE workspace_id=?').all(wsId),
    files: db.prepare('SELECT id,name,mime,size,kind,created_at FROM files WHERE workspace_id=?').all(wsId),
    tasks: db.prepare('SELECT * FROM tasks WHERE workspace_id=?').all(wsId),
    memory: db.prepare('SELECT * FROM memory WHERE workspace_id=?').all(wsId)
  };
  res.setHeader('Content-Disposition', 'attachment; filename="aqlevon-export.json"');
  res.json(dump);
});

// ---------- API 404 + clean error handling (no stack traces to users) ----------
app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));

app.use((err, _req, res, _next) => {
  if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON body' });
  if (err?.name === 'MulterError') {
    const msg = err.code === 'LIMIT_FILE_SIZE' ? 'File too large (max 25 MB)' : 'Upload error';
    return res.status(400).json({ error: msg });
  }
  console.error('[server error]', err?.message || err);
  res.status(500).json({ error: 'Internal server error' });
});

// ---------- static frontend (production build) ----------
// Checked per-request so the server works even if the build lands later.
const dist = path.join(__dirname, '..', 'dist');
app.use((req, res, next) => {
  if (req.path.startsWith('/api')) return next();
  express.static(dist)(req, res, () => {
    const index = path.join(dist, 'index.html');
    if (fs.existsSync(index)) return res.sendFile(index);
    res.status(503).send('AQLEVON UI build not found. Run: npm run build');
  });
});

// ---------- durable job recovery + scheduler start ----------
recoverJobs();
startScheduler();

const port = Number(process.env.PORT || 3000);
app.listen(port, '0.0.0.0', () => {
  console.log(`AQLEVON server on :${port} (AUTH_MODE=${accessMode()})`);
});
