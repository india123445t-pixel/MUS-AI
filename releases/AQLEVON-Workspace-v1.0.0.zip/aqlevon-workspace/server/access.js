// ---------------------------------------------------------------
// Access architecture.
//
// AUTH_MODE=disabled   (default)  -> direct entry. No login, no
//                                    signup, no session gating.
// AUTH_MODE=owner-only (future)   -> API requires the OWNER_TOKEN
//                                    bearer token. Exists only so a
//                                    public deployment can be locked
//                                    down later WITHOUT rebuilding.
// AUTH_MODE=full-auth  (future)   -> reserved for a real multi-user
//                                    auth system. Not implemented;
//                                    treated as owner-only for safety.
//
// This module is the ONLY place access is decided. There are no
// login routes, no session cookies and no redirects anywhere else.
// ---------------------------------------------------------------

const MODE = (process.env.AUTH_MODE || 'disabled').toLowerCase();

export function accessMode() {
  return MODE;
}

export function accessGuard(req, res, next) {
  if (MODE === 'disabled') return next();

  // Future protection modes: bearer-token check only, still no login UI.
  const token = process.env.OWNER_TOKEN;
  const given = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (token && given === token) return next();
  return res.status(401).json({
    error: 'This deployment is running in protected mode (AUTH_MODE=' + MODE + ').'
  });
}
