// ---------------------------------------------------------------
// Real artifact generation: PDF, XLSX, PPTX, DOCX-like structured MD.
// Every generator WRITES a real file and VALIDATES it afterwards
// (magic bytes / zip structure) so corrupted output can never be
// reported as success.
// ---------------------------------------------------------------
import fs from 'fs';
import path from 'path';
import PDFDocument from 'pdfkit';
import ExcelJS from 'exceljs';
import pptxgen from 'pptxgenjs';
import AdmZip from 'adm-zip';
import { UPLOAD_DIR, db, uid, now } from './db.js';

function registerFile(workspaceId, name, mime, storedName, projectId = null) {
  const size = fs.statSync(path.join(UPLOAD_DIR, storedName)).size;
  const id = uid();
  db.prepare(`INSERT INTO files (id, workspace_id, project_id, name, mime, size, kind, stored_name, created_at)
              VALUES (?,?,?,?,?,?,?,?,?)`)
    .run(id, workspaceId, projectId, name, mime, size, 'generated', storedName, now());
  return id;
}

// ---- validators (evidence, not vibes) --------------------------------------
export function validatePdf(p) {
  const buf = fs.readFileSync(p);
  if (!buf.subarray(0, 5).toString().startsWith('%PDF-')) throw new Error('invalid PDF header');
  if (!buf.subarray(-1024).toString('latin1').includes('%%EOF')) throw new Error('PDF missing EOF marker');
  return { bytes: buf.length };
}
export function validateZipBased(p, requiredEntry) {
  const zip = new AdmZip(p);
  const entries = zip.getEntries().map(e => e.entryName);
  if (!entries.some(e => e.startsWith(requiredEntry)))
    throw new Error(`invalid archive: missing ${requiredEntry}`);
  return { bytes: fs.statSync(p).size, entries: entries.length };
}

// ---- generators -------------------------------------------------------------
// content: { title, sections: [{heading, body}] }
export async function generatePdf(workspaceId, name, content, projectId) {
  const stored = uid() + '-' + name;
  const full = path.join(UPLOAD_DIR, stored);
  await new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 50 });
    const ws = fs.createWriteStream(full);
    ws.on('finish', resolve); ws.on('error', reject);
    doc.pipe(ws);
    doc.fontSize(22).text(content.title || 'Document', { underline: false });
    doc.moveDown();
    for (const s of content.sections || []) {
      doc.fontSize(15).fillColor('#333').text(s.heading || '');
      doc.moveDown(0.3);
      doc.fontSize(11).fillColor('#111').text(s.body || '', { align: 'left' });
      doc.moveDown();
    }
    doc.end();
  });
  const v = validatePdf(full);
  return { fileId: registerFile(workspaceId, name, 'application/pdf', stored, projectId), validation: v };
}

// content: { title, headers: [], rows: [[]] }
export async function generateXlsx(workspaceId, name, content, projectId) {
  const stored = uid() + '-' + name;
  const full = path.join(UPLOAD_DIR, stored);
  const wb = new ExcelJS.Workbook();
  const sheet = wb.addWorksheet(content.title?.slice(0, 28) || 'Sheet1');
  if (content.headers?.length) {
    sheet.addRow(content.headers);
    sheet.getRow(1).font = { bold: true };
  }
  for (const row of content.rows || []) sheet.addRow(row);
  sheet.columns.forEach(c => { c.width = 22; });
  await wb.xlsx.writeFile(full);
  const v = validateZipBased(full, 'xl/');
  return { fileId: registerFile(workspaceId, name, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', stored, projectId), validation: v };
}

// content: { title, slides: [{title, bullets: []}] }
export async function generatePptx(workspaceId, name, content, projectId) {
  const stored = uid() + '-' + name;
  const full = path.join(UPLOAD_DIR, stored);
  const pres = new pptxgen();
  const first = pres.addSlide();
  first.addText(content.title || 'Presentation', { x: 0.6, y: 1.8, w: 8.8, fontSize: 34, bold: true });
  for (const s of content.slides || []) {
    const slide = pres.addSlide();
    slide.addText(s.title || '', { x: 0.5, y: 0.35, w: 9, fontSize: 24, bold: true });
    if (s.bullets?.length) {
      slide.addText(s.bullets.map(b => ({ text: b, options: { bullet: true, fontSize: 15 } })),
        { x: 0.7, y: 1.3, w: 8.6, h: 4.5, valign: 'top' });
    }
  }
  await pres.writeFile({ fileName: full });
  const v = validateZipBased(full, 'ppt/');
  return { fileId: registerFile(workspaceId, name, 'application/vnd.openxmlformats-officedocument.presentationml.presentation', stored, projectId), validation: v };
}

export function generateMarkdown(workspaceId, name, text, projectId) {
  const stored = uid() + '-' + name;
  fs.writeFileSync(path.join(UPLOAD_DIR, stored), text);
  const back = fs.readFileSync(path.join(UPLOAD_DIR, stored), 'utf8');
  if (back.length !== text.length) throw new Error('write verification failed');
  return { fileId: registerFile(workspaceId, name, 'text/markdown', stored, projectId), validation: { bytes: back.length } };
}
