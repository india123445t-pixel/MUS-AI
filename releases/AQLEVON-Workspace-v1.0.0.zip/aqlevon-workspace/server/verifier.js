// ---------------------------------------------------------------
// Independent Verifier. The implementing handler cannot mark its own
// work verified: verification runs separate deterministic checks on
// the actual output artifacts. Rule: NO EVIDENCE = NO COMPLETION.
//   artifact  -> file exists, non-empty, magic bytes match the mime
//   research  -> every [n] citation maps to a real retrieved source;
//                no citation points outside the source list
//   code      -> build/tests actually run and exit 0
// ---------------------------------------------------------------
import fs from 'fs';
import path from 'path';
import { execFileSync } from 'child_process';
import { db, UPLOAD_DIR } from './db.js';
import { validatePdf, validateZipBased } from './artifacts.js';

export function verifyJobOutput(type, payload) {
  try {
    if (type === 'artifact') return verifyArtifact(payload);
    if (type === 'research') return verifyResearch(payload);
    if (type === 'code') return verifyCode(payload);
    return { pass: false, reason: 'unknown verification type: ' + type };
  } catch (e) {
    return { pass: false, reason: e.message };
  }
}

function verifyArtifact({ fileId }) {
  const f = db.prepare('SELECT * FROM files WHERE id=?').get(fileId);
  if (!f) return { pass: false, reason: 'file record missing' };
  const full = path.join(UPLOAD_DIR, f.stored_name);
  if (!fs.existsSync(full)) return { pass: false, reason: 'file missing on disk' };
  const size = fs.statSync(full).size;
  if (size === 0) return { pass: false, reason: 'file is empty' };

  if (f.mime === 'application/pdf') {
    const v = validatePdf(full);
    return { pass: true, evidence: `valid PDF, ${v.bytes} bytes` };
  }
  if (f.mime?.includes('spreadsheetml')) {
    const v = validateZipBased(full, 'xl/');
    return { pass: true, evidence: `valid XLSX, ${v.entries} zip entries, ${v.bytes} bytes` };
  }
  if (f.mime?.includes('presentationml')) {
    const v = validateZipBased(full, 'ppt/');
    return { pass: true, evidence: `valid PPTX, ${v.entries} zip entries, ${v.bytes} bytes` };
  }
  // text artifacts: must be readable, non-trivial
  const text = fs.readFileSync(full, 'utf8');
  if (text.trim().length < 20) return { pass: false, reason: 'text artifact too short (' + text.length + ' chars)' };
  return { pass: true, evidence: `text artifact, ${text.length} chars` };
}

function verifyResearch({ report, sources }) {
  if (!report || report.trim().length < 100) return { pass: false, reason: 'report too short' };
  const cited = [...new Set([...report.matchAll(/\[(\d{1,2})\]/g)].map(m => Number(m[1])))];
  if (cited.length === 0) return { pass: false, reason: 'no citations found in report' };
  const max = sources.length;
  const invalid = cited.filter(n => n < 1 || n > max);
  if (invalid.length) return { pass: false, reason: `citations ${JSON.stringify(invalid)} point outside the ${max} retrieved sources (invented sources)` };
  return { pass: true, evidence: `${cited.length} distinct citations, all within ${max} retrieved sources` };
}

function verifyCode({ cwd, buildCmd, testCmd }) {
  const results = {};
  for (const [name, cmd] of [['build', buildCmd], ['test', testCmd]]) {
    if (!cmd) continue;
    try {
      const out = execFileSync('bash', ['-c', cmd], { cwd, timeout: 120000, encoding: 'utf8' });
      results[name] = { ok: true, tail: out.slice(-400) };
    } catch (e) {
      return { pass: false, reason: `${name} failed: ${(e.stdout || e.message).slice(-400)}` };
    }
  }
  if (!Object.keys(results).length) return { pass: false, reason: 'no build/test command provided — no evidence' };
  return { pass: true, evidence: results };
}
