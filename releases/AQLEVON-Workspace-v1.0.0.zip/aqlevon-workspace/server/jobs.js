// ---------------------------------------------------------------
// Durable job runtime.
//  - Jobs live in SQLite (survive crashes/restarts).
//  - A worker loop claims queued jobs (single-writer via UPDATE guard).
//  - Handlers are STEP-BASED: each step's output is checkpointed in
//    job_steps; on resume, completed steps are skipped => real resume,
//    not restart. Crash recovery re-queues interrupted jobs.
//  - Cancellation: cancel_requested flag checked between steps and
//    wired into fetch AbortSignals inside steps.
//  - Idempotency: optional idempotency_key dedupes job creation.
//  - Retries: attempts < max_attempts with backoff.
// ---------------------------------------------------------------
import { db, uid, now } from './db.js';

const CONCURRENCY = Number(process.env.JOB_CONCURRENCY || 2);
const handlers = new Map();          // kind -> async (ctx) => result
const controllers = new Map();       // jobId -> AbortController
let running = 0;
let timer = null;

export function registerHandler(kind, fn) { handlers.set(kind, fn); }

export function createJob({ kind, title, input = {}, workspaceId, idempotencyKey = null, maxAttempts = 3, parentId = null }) {
  if (idempotencyKey) {
    const dup = db.prepare('SELECT * FROM jobs WHERE idempotency_key=?').get(idempotencyKey);
    if (dup) return dup;
  }
  const id = uid();
  const t = now();
  db.prepare(`INSERT INTO jobs (id, workspace_id, kind, title, input, status, max_attempts, idempotency_key, parent_id, created_at, updated_at)
              VALUES (?,?,?,?,?,'queued',?,?,?,?,?)`)
    .run(id, workspaceId, kind, title, JSON.stringify(input), maxAttempts, idempotencyKey, parentId, t, t);
  tick();
  return db.prepare('SELECT * FROM jobs WHERE id=?').get(id);
}

export function getJob(id) { return db.prepare('SELECT * FROM jobs WHERE id=?').get(id); }
export function listJobs(workspaceId, limit = 100) {
  return db.prepare('SELECT * FROM jobs WHERE workspace_id=? ORDER BY created_at DESC LIMIT ?').all(workspaceId, limit);
}

export function cancelJob(id) {
  db.prepare(`UPDATE jobs SET cancel_requested=1, updated_at=? WHERE id=?`).run(now(), id);
  controllers.get(id)?.abort();
  // If still queued, cancel immediately.
  db.prepare(`UPDATE jobs SET status='cancelled', updated_at=? WHERE id=? AND status='queued'`).run(now(), id);
  return getJob(id);
}

export function retryJob(id) {
  db.prepare(`UPDATE jobs SET status='queued', error=NULL, cancel_requested=0, updated_at=?
              WHERE id=? AND status IN ('failed','cancelled')`).run(now(), id);
  tick();
  return getJob(id);
}

// ---- step checkpointing (the core of durable resume) ----------------------
function stepDone(jobId, step) {
  return db.prepare(`SELECT output FROM job_steps WHERE job_id=? AND step=? AND status='done'`).get(jobId, step);
}
function saveStep(jobId, step, output) {
  db.prepare(`INSERT INTO job_steps (job_id, step, status, output, updated_at) VALUES (?,?,'done',?,?)
              ON CONFLICT(job_id, step) DO UPDATE SET output=excluded.output, updated_at=excluded.updated_at`)
    .run(jobId, step, JSON.stringify(output ?? null), now());
}

function makeCtx(job) {
  const controller = new AbortController();
  controllers.set(job.id, controller);
  return {
    id: job.id,
    input: JSON.parse(job.input || '{}'),
    signal: controller.signal,
    // step(name, fn): run once; on resume return the checkpointed output.
    async step(name, fn) {
      const done = stepDone(job.id, name);
      if (done) return JSON.parse(done.output);
      throwIfCancelled(job.id);
      const out = await fn();
      saveStep(job.id, name, out);
      return out;
    },
    progress(p, note = '') {
      db.prepare('UPDATE jobs SET progress=?, progress_note=?, updated_at=? WHERE id=?')
        .run(Math.min(1, Math.max(0, p)), note, now(), job.id);
    },
    cancelled: () => isCancelRequested(job.id)
  };
}

function isCancelRequested(id) {
  return db.prepare('SELECT cancel_requested c FROM jobs WHERE id=?').get(id)?.c === 1;
}
function throwIfCancelled(id) {
  if (isCancelRequested(id)) { const e = new Error('cancelled'); e.code = 'cancelled'; throw e; }
}

// ---- worker loop -----------------------------------------------------------
async function runOne(job) {
  const handler = handlers.get(job.kind);
  const t = now();
  if (!handler) {
    db.prepare(`UPDATE jobs SET status='failed', error=?, updated_at=? WHERE id=?`)
      .run('No handler for kind: ' + job.kind, t, job.id);
    return;
  }
  db.prepare(`UPDATE jobs SET status='running', attempts=attempts+1, updated_at=? WHERE id=?`).run(t, job.id);
  const ctx = makeCtx(job);
  try {
    const result = await handler(ctx);
    throwIfCancelled(job.id);
    db.prepare(`UPDATE jobs SET status='done', result=?, progress=1, updated_at=? WHERE id=?`)
      .run(JSON.stringify(result ?? null), now(), job.id);
  } catch (e) {
    if (e.code === 'cancelled' || isCancelRequested(job.id)) {
      db.prepare(`UPDATE jobs SET status='cancelled', error='Cancelled by user', updated_at=? WHERE id=?`)
        .run(now(), job.id);
    } else {
      const j = getJob(job.id);
      const willRetry = j.attempts < j.max_attempts;
      db.prepare(`UPDATE jobs SET status=?, error=?, updated_at=? WHERE id=?`)
        .run(willRetry ? 'queued' : 'failed', String(e.message).slice(0, 500), now(), job.id);
      if (willRetry) setTimeout(tick, 2000 * j.attempts); // backoff
    }
  } finally {
    controllers.delete(job.id);
    running--;
    setImmediate(tick);
  }
}

export function tick() {
  while (running < CONCURRENCY) {
    // atomically claim one queued job
    const job = db.prepare(`SELECT * FROM jobs WHERE status='queued' ORDER BY created_at LIMIT 1`).get();
    if (!job) return;
    const claimed = db.prepare(`UPDATE jobs SET status='claimed', updated_at=? WHERE id=? AND status='queued'`)
      .run(now(), job.id).changes;
    if (!claimed) continue;
    running++;
    runOne(job);
  }
}

// Crash recovery: anything left claimed/running when the process starts was
// interrupted -> re-queue it. Completed steps are checkpointed, so the job
// RESUMES from where it stopped instead of restarting or being marked failed.
export function recoverJobs() {
  const orphans = db.prepare(`SELECT id, attempts, max_attempts FROM jobs WHERE status IN ('claimed','running')`).all();
  for (const o of orphans) {
    if (o.attempts >= o.max_attempts) {
      db.prepare(`UPDATE jobs SET status='failed', error='Interrupted too many times', updated_at=? WHERE id=?`).run(now(), o.id);
    } else {
      db.prepare(`UPDATE jobs SET status='queued', updated_at=? WHERE id=?`).run(now(), o.id);
    }
  }
  if (orphans.length) console.log(`[jobs] re-queued ${orphans.length} interrupted job(s) for resume`);
  timer = setInterval(tick, 5000);
  timer.unref();
  tick();
}
