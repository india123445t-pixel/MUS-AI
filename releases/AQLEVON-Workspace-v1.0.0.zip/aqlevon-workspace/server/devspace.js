// ---------------------------------------------------------------
// Developer workspace backend: REAL git repositories under data/repos.
//  - create/clone repos, file tree, read/write files
//  - git status, diff, log, branches, commit
//  - checkpoints (git tag) + rollback (git reset --hard) with proof
//  - sandboxed command runner: allowlisted commands only, cwd locked
//    inside the repo, timeout, output captured (never runs on the
//    app server process itself beyond a child process boundary)
//  - repository text search
// GitHub remote integration requires a token: exposed as
// CONFIGURATION REQUIRED until credentials are provided.
// ---------------------------------------------------------------
import fs from 'fs';
import path from 'path';
import { execFileSync, execFile } from 'child_process';
import { db, uid, now, DATA_DIR } from './db.js';

export const REPOS_DIR = path.join(DATA_DIR, 'repos');
fs.mkdirSync(REPOS_DIR, { recursive: true });

const SAFE_NAME = /^[\w.-]{1,64}$/;

function repoPath(name) {
  if (!SAFE_NAME.test(name)) throw new Error('invalid repo name');
  const p = path.join(REPOS_DIR, name);
  if (!p.startsWith(REPOS_DIR)) throw new Error('path escape');
  return p;
}

function insideRepo(repo, rel) {
  const base = repoPath(repo);
  const full = path.resolve(base, rel || '.');
  if (full !== base && !full.startsWith(base + path.sep)) throw new Error('path escape blocked');
  return full;
}

function git(repo, args, opts = {}) {
  return execFileSync('git', args, {
    cwd: repoPath(repo), encoding: 'utf8', timeout: 30000,
    env: { ...process.env, GIT_AUTHOR_NAME: 'AQLEVON', GIT_AUTHOR_EMAIL: 'aqlevon@local', GIT_COMMITTER_NAME: 'AQLEVON', GIT_COMMITTER_EMAIL: 'aqlevon@local' },
    ...opts
  });
}

export function listRepos() {
  return fs.readdirSync(REPOS_DIR).filter(d => {
    try { return fs.statSync(path.join(REPOS_DIR, d, '.git')).isDirectory(); } catch { return false; }
  }).map(name => {
    let branch = '?', dirty = false;
    try {
      branch = git(name, ['rev-parse', '--abbrev-ref', 'HEAD']).trim();
      dirty = git(name, ['status', '--porcelain']).trim().length > 0;
    } catch { /* empty repo */ }
    return { name, branch, dirty };
  });
}

export function createRepo(name) {
  const p = repoPath(name);
  if (fs.existsSync(p)) throw new Error('repo exists');
  fs.mkdirSync(p, { recursive: true });
  execFileSync('git', ['init', '-q', '-b', 'main'], { cwd: p, timeout: 15000 });
  fs.writeFileSync(path.join(p, 'README.md'), `# ${name}\n`);
  // Isolate the repo from the host app's package.json (module resolution
  // walks up directories — without this, repos inherit type:module).
  fs.writeFileSync(path.join(p, 'package.json'), JSON.stringify({ name, version: '0.1.0', private: true }, null, 2));
  git(name, ['add', '-A']);
  git(name, ['commit', '-qm', 'init']);
  return { name };
}

export function fileTree(repo) {
  const base = repoPath(repo);
  const out = [];
  (function walk(dir, rel) {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (e.name === '.git' || e.name === 'node_modules') continue;
      const r = rel ? rel + '/' + e.name : e.name;
      if (e.isDirectory()) { out.push({ path: r, type: 'dir' }); walk(path.join(dir, e.name), r); }
      else out.push({ path: r, type: 'file', size: fs.statSync(path.join(dir, e.name)).size });
    }
  })(base, '');
  return out;
}

export function readRepoFile(repo, rel) {
  const full = insideRepo(repo, rel);
  if (fs.statSync(full).size > 512 * 1024) throw new Error('file too large to open');
  return fs.readFileSync(full, 'utf8');
}

export function writeRepoFile(repo, rel, content) {
  const full = insideRepo(repo, rel);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, content);
  return { ok: true, bytes: Buffer.byteLength(content) };
}

export function gitStatus(repo) {
  return {
    branch: git(repo, ['rev-parse', '--abbrev-ref', 'HEAD']).trim(),
    status: git(repo, ['status', '--porcelain=v1']).trim(),
    log: git(repo, ['log', '--oneline', '-10']).trim()
  };
}

export function gitDiff(repo) {
  // include untracked files in the diff (intent-to-add), then reset
  try { git(repo, ['add', '-N', '.']); } catch { /* empty */ }
  const unstaged = git(repo, ['diff']);
  const staged = git(repo, ['diff', '--cached']);
  return { diff: (staged + '\n' + unstaged).trim() };
}

export function gitCommit(repo, message) {
  git(repo, ['add', '-A']);
  git(repo, ['commit', '-qm', message || 'update']);
  return { sha: git(repo, ['rev-parse', 'HEAD']).trim() };
}

export function branches(repo) {
  return git(repo, ['branch', '--format=%(refname:short)']).trim().split('\n').filter(Boolean);
}
export function createBranch(repo, name) {
  if (!SAFE_NAME.test(name)) throw new Error('invalid branch name');
  git(repo, ['checkout', '-q', '-b', name]);
  return { branch: name };
}
export function checkout(repo, name) {
  if (!SAFE_NAME.test(name)) throw new Error('invalid branch name');
  git(repo, ['checkout', '-q', name]);
  return { branch: name };
}

// ---- checkpoints: git-tag based, rollback provable ----
export function createCheckpoint(repo, label) {
  // commit any pending work into the checkpoint so rollback restores exactly this state
  try { git(repo, ['add', '-A']); git(repo, ['commit', '-qm', 'checkpoint: ' + (label || '')]); } catch { /* nothing to commit */ }
  const sha = git(repo, ['rev-parse', 'HEAD']).trim();
  const id = 'cp-' + uid();
  git(repo, ['tag', id, sha]);
  db.prepare('INSERT INTO checkpoints (id, repo, label, git_ref, created_at) VALUES (?,?,?,?,?)')
    .run(id, repo, label || '', sha, now());
  return { id, sha };
}

export function listCheckpoints(repo) {
  return db.prepare('SELECT * FROM checkpoints WHERE repo=? ORDER BY created_at DESC').all(repo);
}

export function rollback(repo, checkpointId) {
  const cp = db.prepare('SELECT * FROM checkpoints WHERE id=? AND repo=?').get(checkpointId, repo);
  if (!cp) throw new Error('checkpoint not found');
  git(repo, ['reset', '--hard', cp.git_ref]);
  git(repo, ['clean', '-fd']);
  const head = git(repo, ['rev-parse', 'HEAD']).trim();
  return { restored: head === cp.git_ref, head, checkpoint: cp.git_ref };
}

// ---- repository search ----
export function searchRepo(repo, q) {
  try {
    const out = git(repo, ['grep', '-n', '-I', '--max-depth', '10', q]);
    return out.trim().split('\n').slice(0, 100).map(l => {
      const [file, line, ...rest] = l.split(':');
      return { file, line: Number(line), text: rest.join(':').slice(0, 200) };
    });
  } catch { return []; } // git grep exits 1 on no match
}

// ---- sandboxed command runner ----
// Allowlist only; child process with locked cwd + timeout + env scrub.
const ALLOWED = new Set(['node', 'npm', 'npx', 'git', 'ls', 'cat', 'echo', 'pwd', 'grep', 'wc', 'python3']);
export function runSandboxed(repo, command) {
  const [bin] = command.trim().split(/\s+/);
  if (!ALLOWED.has(bin)) throw new Error(`command not allowed: ${bin}. Allowed: ${[...ALLOWED].join(', ')}`);
  return new Promise((resolve) => {
    execFile('bash', ['-c', command], {
      cwd: repoPath(repo),
      timeout: 60000,
      maxBuffer: 1024 * 1024,
      env: { PATH: process.env.PATH, HOME: '/tmp', LANG: 'C.UTF-8' } // secrets scrubbed
    }, (err, stdout, stderr) => {
      resolve({ exitCode: err ? (err.code ?? 1) : 0, stdout: String(stdout).slice(-8000), stderr: String(stderr).slice(-4000), timedOut: err?.killed || false });
    });
  });
}

// ---- GitHub integration boundary ----
export function githubStatus() {
  const token = process.env.GITHUB_TOKEN || db.prepare(`SELECT secret FROM credentials WHERE plugin_id='github' AND status='connected'`).get()?.secret;
  return token ? { configured: true } : { configured: false, message: 'CONFIGURATION REQUIRED: set a GitHub token in Plugins → GitHub to enable clone/push/PRs.' };
}
export async function githubClone(url, name) {
  const st = githubStatus();
  if (!/^https:\/\/github\.com\/[\w.-]+\/[\w.-]+(\.git)?$/.test(url)) throw new Error('only https://github.com/... URLs allowed');
  const p = repoPath(name);
  if (fs.existsSync(p)) throw new Error('repo exists');
  const token = process.env.GITHUB_TOKEN || db.prepare(`SELECT secret FROM credentials WHERE plugin_id='github' AND status='connected'`).get()?.secret;
  const cloneUrl = token ? url.replace('https://', `https://x-access-token:${token}@`) : url; // public repos work without token
  execFileSync('git', ['clone', '--depth', '20', cloneUrl, p], { timeout: 120000 });
  // never persist the token inside the repo config
  try { execFileSync('git', ['remote', 'set-url', 'origin', url], { cwd: p }); } catch {}
  return { name, authenticated: Boolean(token), note: st.configured ? undefined : st.message };
}
