// ---------------------------------------------------------------
// Job handlers: Work deliverables, Deep Research, artifacts, coding.
// All are step-checkpointed => resumable after crash/restart.
// An independent Verifier checks outputs; NO EVIDENCE = NO COMPLETION.
// ---------------------------------------------------------------
import { db, uid, now, WS } from './db.js';
import { registerHandler } from './jobs.js';
import { complete } from './ai.js';
import { webSearch, fetchPage } from './search.js';
import { generatePdf, generateXlsx, generatePptx, generateMarkdown } from './artifacts.js';
import { verifyJobOutput } from './verifier.js';

const wsId = () => WS.wsId;

async function aqlevonOrFail(messages, opts = {}) {
  // AQLEVON is the only inference runtime. Fail closed if it is unavailable.
  try {
    return await complete(messages, opts);
  } catch (e) {
    if (e.code === 'aqlevon_unavailable')
      throw new Error('AQLEVON runtime unavailable.');
    throw e;
  }
}

// ---------------- work.deliverable ----------------
// input: { prompt, kind: report|document|research, format: md|pdf|xlsx|pptx, projectId }
registerHandler('work.deliverable', async (ctx) => {
  const { prompt, kind = 'report', format = 'md', projectId = null, title = 'deliverable' } = ctx.input;

  ctx.progress(0.1, 'Generating content');
  const text = await ctx.step('generate', () => aqlevonOrFail([
    { role: 'system', content: 'You are AQLEVON Work. Produce a complete, well-structured ' + kind + ' in Markdown with headings and sections.' },
    { role: 'user', content: prompt }
  ], { signal: ctx.signal }));

  ctx.progress(0.6, 'Rendering ' + format.toUpperCase());
  const safe = title.replace(/[^\w\u0600-\u06FF\- ]+/g, '').trim().replace(/\s+/g, '-').toLowerCase() || 'deliverable';
  const out = await ctx.step('render', async () => {
    if (format === 'pdf') {
      const sections = splitSections(text);
      return generatePdf(wsId(), safe + '.pdf', { title, sections }, projectId);
    }
    if (format === 'xlsx') {
      const table = await aiTable(text, ctx.signal);
      return generateXlsx(wsId(), safe + '.xlsx', { title, ...table }, projectId);
    }
    if (format === 'pptx') {
      const slides = splitSections(text).slice(0, 10).map(s => ({
        title: s.heading, bullets: s.body.split(/\n+/).filter(Boolean).slice(0, 6).map(b => b.replace(/^[-*]\s*/, '').slice(0, 160))
      }));
      return generatePptx(wsId(), safe + '.pptx', { title, slides }, projectId);
    }
    return generateMarkdown(wsId(), safe + '.md', text, projectId);
  });

  ctx.progress(0.85, 'Verifying output');
  const verification = await ctx.step('verify', () => verifyJobOutput('artifact', { fileId: out.fileId }));
  if (!verification.pass) throw new Error('Verifier rejected output: ' + verification.reason);

  return { fileId: out.fileId, format, verification };
});

function splitSections(md) {
  const parts = md.split(/\n(?=#{1,3}\s)/);
  return parts.map(p => {
    const lines = p.split('\n');
    const heading = lines[0].replace(/^#+\s*/, '').trim() || 'Section';
    return { heading, body: lines.slice(1).join('\n').trim() };
  }).filter(s => s.body || s.heading);
}

async function aiTable(text, signal) {
  const raw = await aqlevonOrFail([
    { role: 'system', content: 'Convert the following content into a compact JSON table: {"headers":[...], "rows":[[...],[...]]} . Reply with JSON only.' },
    { role: 'user', content: text.slice(0, 6000) }
  ], { signal });
  try {
    const j = JSON.parse(raw.replace(/^```json?\s*|```\s*$/g, ''));
    if (Array.isArray(j.headers) && Array.isArray(j.rows)) return j;
  } catch { /* fall through */ }
  return { headers: ['Content'], rows: text.split('\n').filter(Boolean).slice(0, 50).map(l => [l.slice(0, 200)]) };
}

// ---------------- research.deep ----------------
// Real multi-iteration research: plan -> N x (search + retrieval) ->
// evidence -> synthesis with mapped citations -> persisted report.
// input: { question, iterations?: number, projectId }
registerHandler('research.deep', async (ctx) => {
  const { question, iterations = 3, projectId = null } = ctx.input;

  // 1) plan
  ctx.progress(0.05, 'Planning research');
  const plan = await ctx.step('plan', async () => {
    const raw = await aqlevonOrFail([
      { role: 'system', content: 'You are a research planner. Given a question, output JSON only: {"queries": ["q1","q2","q3"]} — ' + iterations + ' distinct web-search queries covering different angles.' },
      { role: 'user', content: question }
    ], { signal: ctx.signal });
    try { return JSON.parse(raw.replace(/^```json?\s*|```\s*$/g, '')); }
    catch { return { queries: [question] }; }
  });

  // 2) iterative search + retrieval, evidence persisted per iteration
  const queries = (plan.queries || [question]).slice(0, Math.max(iterations, 1));
  const evidence = [];
  for (let i = 0; i < queries.length; i++) {
    if (ctx.cancelled()) { const e = new Error('cancelled'); e.code = 'cancelled'; throw e; }
    ctx.progress(0.1 + 0.5 * (i / queries.length), `Searching (${i + 1}/${queries.length}): ${queries[i].slice(0, 60)}`);
    const iter = await ctx.step('search-' + i, async () => {
      const { results, engine, errors } = await webSearch(queries[i], { limit: 5 });
      const fetched = [];
      for (const r of results.slice(0, 3)) {
        const page = await fetchPage(r.url, { maxChars: 4000 });
        fetched.push({ ...r, fetched: page.ok, content: page.ok ? page.text : null, fetchError: page.ok ? null : page.error });
      }
      return { query: queries[i], engine, errors, sources: fetched };
    });
    for (const s of iter.sources) {
      const eid = uid();
      db.prepare(`INSERT OR IGNORE INTO evidence (id, job_id, url, title, snippet, fetched, content, created_at)
                  VALUES (?,?,?,?,?,?,?,?)`)
        .run(eid, ctx.id, s.url, s.title, s.snippet, s.fetched ? 1 : 0, s.content?.slice(0, 4000) || null, now());
      evidence.push(s);
    }
  }

  const usable = evidence.filter(e => e.fetched);
  if (usable.length === 0) throw new Error('Research failed: no sources could be retrieved. Engines tried and errors are recorded in evidence.');

  // 3) synthesis with strict citation mapping (only numbered, retrieved sources)
  ctx.progress(0.7, 'Synthesizing findings from ' + usable.length + ' sources');
  const numbered = usable.map((s, i) => `[${i + 1}] ${s.title} — ${s.url}\n${(s.content || s.snippet || '').slice(0, 1500)}`).join('\n\n');
  const report = await ctx.step('synthesize', () => aqlevonOrFail([
    { role: 'system', content: 'You are a research writer. Write a structured Markdown report answering the question using ONLY the numbered sources provided. Cite claims as [n] matching the source list exactly. Do NOT invent sources. Include a "## Sources" section listing each [n] with its URL. If sources disagree, state the disagreement.' },
    { role: 'user', content: 'Question: ' + question + '\n\nSources:\n' + numbered }
  ], { signal: ctx.signal }));

  // 4) persist report
  ctx.progress(0.9, 'Saving report');
  const saved = await ctx.step('persist', () =>
    generateMarkdown(wsId(), 'research-' + ctx.id + '.md', report, projectId));

  // 5) independent verification of citation integrity
  const verification = await ctx.step('verify', () =>
    verifyJobOutput('research', { report, sources: usable.map(s => s.url) }));
  if (!verification.pass) throw new Error('Verifier rejected research: ' + verification.reason);

  return { fileId: saved.fileId, sources: usable.length, totalCandidates: evidence.length, verification };
});

// ---------------- director ----------------
// Orchestrator: classifies a goal, either answers directly (simple)
// or plans steps and spawns child jobs (complex), with concurrency
// bounded by the jobs runtime itself. No busy-wait loops.
registerHandler('director', async (ctx) => {
  const { goal } = ctx.input;
  ctx.progress(0.1, 'Classifying task');
  const cls = await ctx.step('classify', async () => {
    const raw = await aqlevonOrFail([
      { role: 'system', content: 'Classify the user goal. JSON only: {"complexity":"simple|complex","needs":["research"|"document"|"code"...],"plan":["step1",...]}. simple = answerable in one reply, no tools.' },
      { role: 'user', content: goal }
    ], { signal: ctx.signal });
    try { return JSON.parse(raw.replace(/^```json?\s*|```\s*$/g, '')); }
    catch { return { complexity: 'simple', needs: [], plan: [] }; }
  });

  if (cls.complexity === 'simple') {
    const answer = await ctx.step('answer', () => aqlevonOrFail([
      { role: 'system', content: 'Answer directly and concisely in Markdown.' },
      { role: 'user', content: goal }
    ], { signal: ctx.signal }));
    return { mode: 'direct', answer, plan: null };
  }

  // Complex: spawn bounded child jobs (max 3, no recursion into director)
  ctx.progress(0.4, 'Delegating to specialist jobs');
  const children = await ctx.step('spawn', async () => {
    const out = [];
    const needs = (cls.needs || []).slice(0, 3);
    const { createJob } = await import('./jobs.js');
    for (const need of needs) {
      if (need === 'research') {
        out.push(createJob({ kind: 'research.deep', title: 'Research: ' + goal.slice(0, 50), input: { question: goal, iterations: 2 }, workspaceId: wsId(), parentId: ctx.id }).id);
      } else {
        out.push(createJob({ kind: 'work.deliverable', title: 'Deliverable: ' + goal.slice(0, 50), input: { prompt: goal, format: 'md', title: need }, workspaceId: wsId(), parentId: ctx.id }).id);
      }
    }
    return out;
  });
  return { mode: 'orchestrated', plan: cls.plan, childJobs: children };
});
