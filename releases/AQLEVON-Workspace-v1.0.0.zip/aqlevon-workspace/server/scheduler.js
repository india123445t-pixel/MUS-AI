// ---------------------------------------------------------------
// Real scheduler: a server-side loop that EXECUTES scheduled tasks.
// - one-time:   runs at `next_run` (ISO datetime, interpreted in the
//               schedule's timezone if given as local time)
// - recurring:  every `interval_minutes`, next_run advanced each run
// - monitor:    runs a real web search for `condition_query` each
//               interval and records what it found
// Runs are recorded in schedule_runs (history). Enabled/disabled
// respected. Survives restarts (next_run persisted). Does NOT depend
// on any browser being open.
// ---------------------------------------------------------------
import { db, uid, now, WS } from './db.js';
import { createJob } from './jobs.js';
import { webSearch } from './search.js';

const TICK_MS = Number(process.env.SCHEDULER_TICK_MS || 20000);

export function computeNextRun(item) {
  if (item.kind === 'once') return item.next_run; // fixed
  const iv = Math.max(1, item.interval_minutes || 60);
  return new Date(Date.now() + iv * 60000).toISOString();
}

async function runScheduled(item) {
  const runId = uid();
  db.prepare(`INSERT INTO schedule_runs (id, schedule_id, started_at, status, detail) VALUES (?,?,?,?,?)`)
    .run(runId, item.id, now(), 'ok', 'started');
  let status = 'ok', detail = '';
  try {
    if (item.kind === 'monitor' && item.condition_query) {
      const { results, engine, errors } = await webSearch(item.condition_query, { limit: 3 });
      detail = results.length
        ? `engine=${engine}; top: ` + results.map(r => r.title).join(' | ').slice(0, 400)
        : 'no results; errors: ' + JSON.stringify(errors).slice(0, 300);
    } else if (item.prompt) {
      const job = createJob({
        kind: 'work.deliverable',
        title: 'Scheduled: ' + item.title,
        input: { prompt: item.prompt, format: 'md', title: item.title },
        workspaceId: WS.wsId,
        idempotencyKey: 'sched-' + item.id + '-' + (item.next_run || now())
      });
      detail = 'spawned job ' + job.id;
    } else {
      detail = 'nothing to do (no prompt/condition)';
    }
  } catch (e) {
    status = 'failed';
    detail = e.message.slice(0, 400);
  }
  db.prepare(`UPDATE schedule_runs SET finished_at=?, status=?, detail=? WHERE id=?`)
    .run(now(), status, detail, runId);

  const t = now();
  if (item.kind === 'once') {
    db.prepare(`UPDATE scheduled SET enabled=0, last_run=?, next_run=NULL WHERE id=?`).run(t, item.id);
  } else {
    db.prepare(`UPDATE scheduled SET last_run=?, next_run=? WHERE id=?`).run(t, computeNextRun(item), item.id);
  }
}

let timer = null;
export function startScheduler() {
  timer = setInterval(() => {
    const due = db.prepare(
      `SELECT * FROM scheduled WHERE enabled=1 AND next_run IS NOT NULL AND next_run <= ?`
    ).all(new Date().toISOString());
    for (const item of due) {
      // claim: null next_run first so a slow run can't double-fire
      const claimed = db.prepare(`UPDATE scheduled SET next_run=NULL WHERE id=? AND next_run=?`)
        .run(item.id, item.next_run).changes;
      if (claimed) runScheduled(item);
    }
  }, TICK_MS);
  timer.unref();
  console.log(`[scheduler] running (tick ${TICK_MS / 1000}s)`);
}
