// ---------------------------------------------------------------
// Real web search + retrieval. No simulation:
//  - Engine chain with failover. Each engine does a real HTTP query.
//  - Page retrieval fetches and extracts readable text.
//  - Dedup by URL host+path; failures reported per-source.
// Engines: SearXNG JSON instances (general web) -> Wikipedia API
// (encyclopedic fallback that works without keys). If a Brave/Serper
// key is configured in settings, it is used first.
// ---------------------------------------------------------------
import { getSetting } from './db.js';

const UA = 'Mozilla/5.0 (X11; Linux x86_64) AQLEVONWorkspace/1.0';
const SEARX = ['https://searx.tiekoetter.com', 'https://search.bus-hit.me', 'https://searx.work', 'https://opnxng.com/searxng'];

async function tryFetch(url, opts = {}, ms = 8000) {
  const r = await fetch(url, { headers: { 'User-Agent': UA, ...(opts.headers || {}) }, signal: AbortSignal.timeout(ms), ...opts });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r;
}

async function braveSearch(q, key) {
  const r = await tryFetch('https://api.search.brave.com/res/v1/web/search?q=' + encodeURIComponent(q),
    { headers: { 'X-Subscription-Token': key, Accept: 'application/json' } });
  const j = await r.json();
  return (j.web?.results || []).map(x => ({
    url: x.url, title: x.title, snippet: x.description || '', published: x.age || null, engine: 'brave'
  }));
}

async function searxSearch(q) {
  let lastErr;
  for (const base of SEARX) {
    try {
      const r = await tryFetch(`${base}/search?q=${encodeURIComponent(q)}&format=json&safesearch=1`, {}, 6000);
      const j = await r.json();
      const res = (j.results || []).map(x => ({
        url: x.url, title: x.title, snippet: x.content || '', published: x.publishedDate || null, engine: 'searxng'
      }));
      if (res.length) return res;
    } catch (e) { lastErr = e; }
  }
  throw lastErr || new Error('all searx instances failed');
}

async function wikiSearch(q) {
  const r = await tryFetch('https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=' +
    encodeURIComponent(q) + '&format=json&srlimit=8&srprop=snippet|timestamp');
  const j = await r.json();
  return (j.query?.search || []).map(x => ({
    url: 'https://en.wikipedia.org/wiki/' + encodeURIComponent(x.title.replace(/ /g, '_')),
    title: x.title,
    snippet: x.snippet.replace(/<[^>]+>/g, ''),
    published: x.timestamp || null,
    engine: 'wikipedia'
  }));
}

// Public: real search with engine failover + dedup.
// Returns { results, engine, errors:[{engine,error}] }
export async function webSearch(q, { limit = 8 } = {}) {
  const errors = [];
  const braveKey = process.env.BRAVE_API_KEY || getSetting('brave_api_key', '');
  const chain = [];
  if (braveKey) chain.push(['brave', () => braveSearch(q, braveKey)]);
  chain.push(['searxng', () => searxSearch(q)]);
  chain.push(['wikipedia', () => wikiSearch(q)]);

  for (const [name, fn] of chain) {
    try {
      const raw = await fn();
      const seen = new Set();
      const results = [];
      for (const r of raw) {
        if (!r.url?.startsWith('http')) continue;
        let key;
        try { const u = new URL(r.url); key = u.host + u.pathname; } catch { continue; }
        if (seen.has(key)) continue;
        seen.add(key);
        results.push(r);
        if (results.length >= limit) break;
      }
      if (results.length) return { results, engine: name, errors };
      errors.push({ engine: name, error: 'no results' });
    } catch (e) {
      errors.push({ engine: name, error: e.message });
    }
  }
  return { results: [], engine: null, errors };
}

// Public: fetch a page and extract readable text. Never throws; returns {ok,...}
export async function fetchPage(url, { maxChars = 6000 } = {}) {
  try {
    const u = new URL(url);
    if (!/^https?:$/.test(u.protocol)) return { ok: false, url, error: 'unsupported protocol' };
    // SSRF guard: block private/link-local hosts
    if (/^(localhost|127\.|10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.|169\.254\.|\[?::1)/.test(u.hostname))
      return { ok: false, url, error: 'blocked host' };
    const r = await tryFetch(url, {}, 10000);
    const ct = r.headers.get('content-type') || '';
    if (!ct.includes('html') && !ct.includes('text') && !ct.includes('json'))
      return { ok: false, url, error: 'not a text page: ' + ct.split(';')[0] };
    let html = await r.text();
    if (html.length > 800000) html = html.slice(0, 800000);
    const text = html
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<nav[\s\S]*?<\/nav>/gi, ' ')
      .replace(/<!--[\s\S]*?-->/g, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
      .replace(/\s+/g, ' ')
      .trim();
    return { ok: true, url, text: text.slice(0, maxChars) };
  } catch (e) {
    return { ok: false, url, error: e.message };
  }
}
