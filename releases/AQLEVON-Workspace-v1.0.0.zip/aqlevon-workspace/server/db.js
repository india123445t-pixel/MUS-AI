import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// AQLEVON_DATA_DIR is canonical. KITE_DATA_DIR remains a compatibility alias
// so an existing owner volume is opened in place without migration or data loss.
export const DATA_DIR = process.env.AQLEVON_DATA_DIR || process.env.KITE_DATA_DIR || path.join(__dirname, '..', 'data');
export const UPLOAD_DIR = path.join(DATA_DIR, 'files');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const legacyDb = path.join(DATA_DIR, 'kite.db');
const canonicalDb = path.join(DATA_DIR, 'aqlevon.db');
export const DB_PATH = fs.existsSync(legacyDb) ? legacyDb : canonicalDb;
export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000'); // wait instead of failing on concurrent writes

db.exec(`
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'owner',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS workspaces (
  id TEXT PRIMARY KEY,
  owner_id TEXT NOT NULL REFERENCES users(id),
  name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id),
  name TEXT NOT NULL,
  instructions TEXT DEFAULT '',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS chats (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id),
  project_id TEXT REFERENCES projects(id),
  title TEXT NOT NULL DEFAULT 'New chat',
  temporary INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  chat_id TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS files (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id),
  project_id TEXT REFERENCES projects(id),
  name TEXT NOT NULL,
  mime TEXT,
  size INTEGER,
  kind TEXT NOT NULL DEFAULT 'uploaded', -- uploaded | generated | image
  stored_name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id),
  project_id TEXT REFERENCES projects(id),
  title TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'report', -- report | document | research
  prompt TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued', -- queued | running | done | failed
  result_file_id TEXT,
  error TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS scheduled (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id),
  title TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'once', -- once | recurring | monitor
  schedule TEXT NOT NULL,            -- ISO datetime or human recurrence text
  prompt TEXT DEFAULT '',
  enabled INTEGER NOT NULL DEFAULT 1,
  last_run TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS plugins (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  installed INTEGER NOT NULL DEFAULT 0,
  enabled INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);

CREATE TABLE IF NOT EXISTS memory (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id),
  content TEXT NOT NULL,
  created_at TEXT NOT NULL
);
`);

export const uid = () => crypto.randomBytes(9).toString('base64url');
export const now = () => new Date().toISOString();

// ---------------------------------------------------------------
// Default owner / workspace bootstrap (single-user, direct-access).
// This identity is an internal implementation detail: it is created
// once on first server start and reused forever after, so data
// persists across visits and no anonymous user is ever created
// per request or per refresh.
// ---------------------------------------------------------------
export function bootstrapWorkspace() {
  let ownerId = db.prepare(`SELECT value FROM meta WHERE key='owner_id'`).get()?.value;
  let wsId = db.prepare(`SELECT value FROM meta WHERE key='workspace_id'`).get()?.value;

  if (!ownerId || !db.prepare('SELECT 1 FROM users WHERE id=?').get(ownerId)) {
    ownerId = 'owner-' + uid();
    db.prepare('INSERT INTO users (id, name, kind, created_at) VALUES (?,?,?,?)')
      .run(ownerId, 'Workspace Owner', 'owner', now());
    db.prepare(`INSERT INTO meta (key, value) VALUES ('owner_id', ?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value`).run(ownerId);
  }

  if (!wsId || !db.prepare('SELECT 1 FROM workspaces WHERE id=?').get(wsId)) {
    wsId = 'ws-' + uid();
    db.prepare('INSERT INTO workspaces (id, owner_id, name, created_at) VALUES (?,?,?,?)')
      .run(wsId, ownerId, 'Default workspace', now());
    db.prepare(`INSERT INTO meta (key, value) VALUES ('workspace_id', ?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value`).run(wsId);
  }

  // Seed plugin directory once
  if (db.prepare('SELECT COUNT(*) c FROM plugins').get().c === 0) {
    const seed = db.prepare('INSERT INTO plugins (id, name, description) VALUES (?,?,?)');
    [
      ['web-search', 'Web Search', 'Let the assistant search the web for current information.'],
      ['code-interpreter', 'Code Interpreter', 'Run Python code in a sandbox for analysis and charts.'],
      ['image-gen', 'Image Generation', 'Generate and edit images with an image model.'],
      ['github', 'GitHub', 'Browse repositories, diffs and pull requests.'],
      ['calendar', 'Calendar', 'Read and create calendar events.'],
      ['drive', 'Cloud Drive', 'Access files from a connected cloud drive.']
    ].forEach(p => seed.run(...p));
  }

  return { ownerId, wsId };
}

export const WS = bootstrapWorkspace();

export function getSetting(key, fallback = null) {
  const row = db.prepare('SELECT value FROM settings WHERE key=?').get(key);
  return row ? row.value : fallback;
}
export function setSetting(key, value) {
  db.prepare(`INSERT INTO settings (key, value) VALUES (?,?)
              ON CONFLICT(key) DO UPDATE SET value=excluded.value`).run(key, String(value));
}
