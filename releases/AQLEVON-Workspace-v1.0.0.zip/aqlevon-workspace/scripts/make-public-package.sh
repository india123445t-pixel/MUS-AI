#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "Refusing to package a dirty working tree. Commit/review changes first." >&2
  exit 2
fi

OUT="${1:-$ROOT/AQLEVON-public-source.zip}"
mkdir -p "$(dirname "$OUT")"
rm -f "$OUT"

# Archive only product source/config/tests. Local data, .env, .git, generated
# evidence, test residue and owner files are intentionally outside this list.
git archive --format=zip --prefix=aqlevon-workspace/ -o "$OUT" HEAD -- \
  .env.example .gitignore README.md package.json package-lock.json index.html \
  vite.config.js eslint.config.js playwright.config.js public server src tests tests-server scripts

echo "$OUT"
