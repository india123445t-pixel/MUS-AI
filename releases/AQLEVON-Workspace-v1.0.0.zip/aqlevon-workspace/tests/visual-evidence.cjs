// Visual QA evidence generator — runs against the ISOLATED test server (:3211,
// its own .test-data/visual dir). Captures the reconstructed UI in
// {desktop,mobile} x {en,ar} x {dark,light} across representative pages.
// Output: docs/evidence/visual/*.png
const { chromium } = require('@playwright/test');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');

const ROOT = path.dirname(__dirname);
const OUT = path.join(ROOT, 'docs', 'evidence', 'visual');
const PORT = 3211;
const DATA = path.join(ROOT, '.test-data', 'visual');

const portOpen = p => new Promise(r => {
  const s = net.connect(p, '127.0.0.1');
  s.once('connect', () => { s.destroy(); r(true); });
  s.once('error', () => { s.destroy(); r(false); });
});

async function main() {
  fs.rmSync(DATA, { recursive: true, force: true });
  fs.mkdirSync(OUT, { recursive: true });

  // mock AQLEVON-compatible runtime
  if (!(await portOpen(4998))) {
    spawn('node', ['tests-server/fixtures/mock-provider.cjs'], { cwd: ROOT, stdio: 'ignore', detached: true }).unref();
    for (let i = 0; i < 40 && !(await portOpen(4998)); i++) await new Promise(r => setTimeout(r, 250));
  }
  // isolated server
  const srv = spawn('node', ['server/index.js'], {
    cwd: ROOT, stdio: 'ignore',
    env: { ...process.env, PORT: String(PORT), AQLEVON_DATA_DIR: DATA, AQLEVON_MODEL_URL: 'http://127.0.0.1:4998/v1', AQLEVON_MODEL_NAME: 'AQLEVON-27B' }
  });
  for (let i = 0; i < 60 && !(await portOpen(PORT)); i++) await new Promise(r => setTimeout(r, 250));
  const B = `http://localhost:${PORT}`;

  // seed representative data; AQLEVON runtime is configured by the isolated server environment
  const j = (p, body, method = 'POST') => fetch(B + '/api' + p, {
    method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  }).then(r => r.json());

  const chat1 = await j('/chats', {});
  await fetch(`${B}/api/chats/${chat1.id}/stream`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: 'Draft a launch plan for our Tangier coworking space, with a 3-phase rollout and budget outline' }) }).then(r => r.text());
  const chat2 = await j('/chats', {});
  await fetch(`${B}/api/chats/${chat2.id}/stream`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: 'ما هي أفضل الممارسات لإدارة مشروع برمجي صغير؟ أعطني خطة أسبوعية مفصلة' }) }).then(r => r.text());
  await j('/chats/' + chat1.id, { pinned: true, title: 'Launch plan — coworking space' }, 'PATCH');
  await j('/chats/' + chat2.id, { title: 'خطة إدارة مشروع برمجي' }, 'PATCH');
  const proj = await j('/projects', { name: 'Website redesign', instructions: 'Prefer concise deliverables. Audience: SMB owners.' });
  const job = await j('/jobs', { kind: 'work.deliverable', title: 'Q4 market brief', prompt: 'Write a short Q4 market brief', format: 'pdf' });
  await j('/scheduled', { title: 'Morning news digest', kind: 'recurring', prompt: 'Summarize top tech news', intervalMinutes: 1440 });
  await new Promise(r => setTimeout(r, 6000)); // let job complete

  const browser = await chromium.launch();
  const shots = [];
  const capture = async (ctxOpts, label, lang, theme, pages) => {
    const ctx = await browser.newContext(ctxOpts);
    const page = await ctx.newPage();
    await page.goto(B + '/chat');
    await page.evaluate(([l, t]) => {
      localStorage.setItem('aqlevon-lang', l);
      localStorage.setItem('aqlevon-theme', t);
    }, [lang, theme]);
    for (const [name, url, extra] of pages) {
      await page.goto(B + url);
      await page.waitForTimeout(700);
      if (extra) await extra(page);
      const f = `${label}-${lang}-${theme}-${name}.png`;
      await page.screenshot({ path: path.join(OUT, f), fullPage: false });
      shots.push(f);
    }
    await ctx.close();
  };

  const desktopPages = [
    ['chat-empty', '/chat'],
    ['chat-conversation', '/chat/' + chat1.id],
    ['work-task', '/work/' + job.id],
    ['library', '/library'],
    ['automations', '/scheduled'],
    ['apps', '/plugins'],
    ['settings-advanced', '/settings/advanced'],
    ['project', '/projects/' + proj.id]
  ];
  const mobilePages = [
    ['chat-empty', '/chat'],
    ['chat-conversation', '/chat/' + (0 ? chat1.id : chat2.id)],
    ['drawer', '/chat', async p => { await p.locator('.topbar .hamburger').click(); await p.waitForTimeout(400); }]
  ];

  const desktop = { viewport: { width: 1440, height: 900 } };
  const mobile = { viewport: { width: 393, height: 851 }, isMobile: true, hasTouch: true };

  await capture(desktop, 'desktop', 'en', 'dark', desktopPages);
  await capture(desktop, 'desktop', 'en', 'light', [['chat-conversation', '/chat/' + chat1.id], ['settings-appearance', '/settings/appearance']]);
  await capture(desktop, 'desktop', 'ar', 'dark', [['chat-empty', '/chat'], ['chat-conversation', '/chat/' + chat2.id], ['work', '/work'], ['settings-language', '/settings/language']]);
  await capture(desktop, 'desktop', 'ar', 'light', [['chat-conversation', '/chat/' + chat2.id]]);
  await capture(mobile, 'mobile', 'en', 'dark', mobilePages);
  await capture(mobile, 'mobile', 'ar', 'dark', [['chat-empty', '/chat'], ['chat-conversation', '/chat/' + chat2.id], ['drawer', '/chat', async p => { await p.locator('.topbar .hamburger').click(); await p.waitForTimeout(400); }]]);
  await capture(mobile, 'mobile', 'en', 'light', [['chat-conversation', '/chat/' + chat1.id]]);

  await browser.close();
  srv.kill();
  console.log('captured ' + shots.length + ' screenshots:');
  shots.forEach(s => console.log('  ' + s));
}

main().catch(e => { console.error(e); process.exit(1); });
