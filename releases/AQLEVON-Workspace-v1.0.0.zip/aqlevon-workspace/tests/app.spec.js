// Browser E2E: real click-through of every section with console monitoring.
// The mock AQLEVON runtime on :4998 gives deterministic streaming replies.
// Runs against the DEDICATED test server (:3210, .test-data/e2e) — never owner data.
import { test, expect } from '@playwright/test';

let consoleErrors = [];
test.beforeEach(async ({ page }) => {
  consoleErrors = [];
  page.on('console', msg => {
    if (msg.type() === 'error') consoleErrors.push(msg.text());
  });
  page.on('pageerror', err => consoleErrors.push('PAGEERROR: ' + err.message));
});
test.afterEach(() => {
  const real = consoleErrors.filter(e =>
    !e.includes('favicon') && !e.includes('net::ERR_ABORTED') &&
    !e.includes('status of 404')); // intentional 404s (missing chat redirect test) are expected
  expect(real, 'no console errors allowed').toEqual([]);
});

const HERO = /How can I help/;

test('direct entry: / opens chat workspace, no login', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveURL(/\/chat$/);
  await expect(page.getByRole('heading', { name: HERO })).toBeVisible();
  // no sign-in anywhere
  await expect(page.getByText(/sign in|log in|register|create account/i)).toHaveCount(0);
});

test('chat: send message, streamed reply appears and persists after reload', async ({ page }) => {
  await page.goto('/chat');
  const box = page.getByPlaceholder('Message AQLEVON…');
  await box.fill('E2E streaming test message');
  await box.press('Enter');
  await expect(page.getByText(/Streamed reply about/)).toBeVisible({ timeout: 15000 });
  const url = page.url();
  await page.reload();
  await expect(page.getByText('E2E streaming test message').first()).toBeVisible();
  await expect(page.getByText(/Streamed reply about/).first()).toBeVisible();
  expect(page.url()).toBe(url);
});

test('chat: copy / edit / retry / branch actions exist and work', async ({ page }) => {
  await page.goto('/chat');
  const box = page.getByPlaceholder('Message AQLEVON…');
  await box.fill('buttons test');
  await box.press('Enter');
  await expect(page.getByText(/Streamed reply about/)).toBeVisible({ timeout: 15000 });
  const userMsg = page.locator('.msg.user').first();
  await userMsg.hover();
  await expect(userMsg.getByTitle('Edit')).toBeVisible();
  await expect(userMsg.getByTitle('Copy')).toBeVisible();
  const aiMsg = page.locator('.msg.assistant').last();
  await aiMsg.hover();
  await expect(aiMsg.getByTitle('Retry')).toBeVisible();
  // branch creates a new conversation
  await aiMsg.getByTitle('Branch from here').click();
  await expect(page).toHaveURL(/\/chat\/.+/);
});

test('chat: AQLEVON is built in with no model selector; Think longer stays same runtime', async ({ page }) => {
  await page.goto('/chat');
  await expect(page.locator('.model-chip')).toHaveCount(0);
  await expect(page.getByText(/Auto|Balanced|Deep/, { exact: true })).toHaveCount(0);
  const think = page.getByRole('button', { name: 'Think longer' });
  await expect(think).toBeVisible();
  await expect(think).toHaveAttribute('aria-pressed', 'false');
  await think.click();
  await expect(think).toHaveAttribute('aria-pressed', 'true');
});

test('search modal (Ctrl+K) finds conversations', async ({ page }) => {
  await page.goto('/chat');
  await page.getByRole('heading', { name: HERO }).waitFor(); // app mounted
  await page.keyboard.press('Control+k');
  const input = page.getByPlaceholder('Search conversations…');
  await expect(input).toBeVisible();
  await input.fill('streaming');
  await expect(page.locator('.modal .recent-item').first()).toBeVisible();
  await page.keyboard.press('Escape');
});

test('sidebar: pin and rename a conversation from hover menu', async ({ page }) => {
  await page.goto('/chat');
  const box = page.getByPlaceholder('Message AQLEVON…');
  await box.fill('pin me test');
  await box.press('Enter');
  await expect(page.getByText(/Streamed reply about/)).toBeVisible({ timeout: 15000 });
  const item = page.locator('.sidebar .recent-item', { hasText: 'pin me test' }).first();
  await item.hover();
  await item.locator('.rmenu').click();
  await page.locator('.menu').getByText('Pin', { exact: true }).click();
  // pinned group appears
  await expect(page.locator('.sidebar').getByText('Pinned')).toBeVisible();
  // rename
  const pinned = page.locator('.sidebar .recent-item', { hasText: 'pin me test' }).first();
  await pinned.hover();
  await pinned.locator('.rmenu').click();
  await page.locator('.menu').getByText('Rename', { exact: true }).click();
  const edit = page.locator('.sidebar .recent-rename');
  await edit.fill('renamed pin e2e');
  await edit.press('Enter');
  await expect(page.locator('.sidebar').getByText('renamed pin e2e')).toBeVisible();
});

test('projects: create, instructions, tabs work', async ({ page }) => {
  await page.goto('/projects');
  await page.getByRole('button', { name: 'New project' }).click();
  await page.locator('.modal input').fill('E2E Project');
  await page.locator('.modal textarea').fill('E2E project instructions');
  await page.locator('.modal').getByRole('button', { name: 'Create', exact: true }).click();
  await expect(page).toHaveURL(/\/projects\/.+/);
  await expect(page.getByRole('heading', { name: /E2E Project/ })).toBeVisible();
  // instructions live under the Instructions tab and persist
  await page.reload();
  await page.getByRole('button', { name: 'Instructions' }).click();
  await expect(page.locator('.settings-body textarea, .card textarea').first()).toHaveValue('E2E project instructions');
});

test('library: upload via UI and see the file listed', async ({ page }) => {
  await page.goto('/library');
  const fileInput = page.locator('input[type=file]');
  await fileInput.setInputFiles({ name: 'e2e-upload.txt', mimeType: 'text/plain', buffer: Buffer.from('e2e file content') });
  await expect(page.getByText('e2e-upload.txt')).toBeVisible({ timeout: 5000 });
  await page.reload();
  await expect(page.getByText('e2e-upload.txt')).toBeVisible();
});

test('work: create a document task, timeline completes, result appears', async ({ page }) => {
  await page.goto('/work');
  await page.getByRole('button', { name: 'New task' }).click();
  await page.locator('.modal textarea').fill('E2E: produce a short report');
  await page.locator('.modal').getByRole('button', { name: 'Document (PDF)' }).click();
  await page.locator('.modal').getByRole('button', { name: 'Start task' }).click();
  // navigates into the task workspace
  await expect(page).toHaveURL(/\/work\/.+/, { timeout: 10000 });
  await expect(page.locator('.topbar .tag', { hasText: 'Done' })).toBeVisible({ timeout: 30000 });
  await expect(page.getByText('Open result')).toBeVisible();
  // internal job ids only inside the Details disclosure, not in the main surface
  await expect(page.locator('.timeline')).toBeVisible();
});

test('developer: create repo, edit file, checkpoint, break, rollback restores', async ({ page }) => {
  await page.goto('/developer');
  await page.getByPlaceholder('new-repo-name').fill('e2e-repo');
  await page.getByRole('button', { name: 'Create', exact: true }).click();
  await page.locator('.app-card', { hasText: 'e2e-repo' }).click();
  // open README
  await page.locator('.tree-item', { hasText: 'README.md' }).click();
  const editor = page.locator('.dev-editor textarea');
  await expect(editor).toHaveValue(/# e2e-repo/);
  // checkpoint (accept dialog)
  page.once('dialog', d => d.accept('cp1'));
  await page.getByRole('button', { name: 'Checkpoint', exact: true }).click();
  await expect(page.locator('.dev-rail').getByText('cp1')).toBeVisible();
  // break the file and save
  await editor.fill('BROKEN E2E CONTENT');
  await page.getByRole('button', { name: 'Save', exact: true }).click();
  // rollback from the checkpoints rail
  page.once('dialog', d => d.accept());
  await page.locator('.dev-rail').getByRole('button', { name: 'Roll back' }).first().click();
  // file restored
  await page.locator('.tree-item', { hasText: 'README.md' }).click();
  await expect(editor).toHaveValue(/# e2e-repo/);
});

test('automations: create repeating task, shows friendly schedule + next run', async ({ page }) => {
  await page.goto('/scheduled');
  await page.getByRole('button', { name: 'New automation' }).click();
  await page.locator('.modal input.input').first().fill('E2E recurring');
  await page.locator('.modal textarea').fill('generate a note');
  await page.locator('.modal').getByRole('button', { name: 'Repeating' }).click();
  await page.locator('.modal').getByRole('button', { name: 'Create', exact: true }).click();
  await expect(page.getByText('E2E recurring')).toBeVisible();
  await expect(page.getByText(/Next run/).first()).toBeVisible();
  // no raw execution ids on the surface
  await expect(page.locator('.auto-card').getByText(/job-[a-z0-9]/i)).toHaveCount(0);
});

test('apps: built-in tools separated from external apps; bad token shows real error', async ({ page }) => {
  await page.goto('/plugins');
  await expect(page.getByText('Built-in tools')).toBeVisible();
  await expect(page.getByText('Connected apps')).toBeVisible();
  const gh = page.locator('.app-card', { hasText: 'GitHub' });
  await gh.getByRole('button', { name: /Connect/ }).click();
  await page.locator('.modal input[type=password]').fill('ghp_e2e_invalid_token');
  await page.locator('.modal').getByRole('button', { name: 'Connect', exact: true }).click();
  await expect(page.locator('.modal').getByText(/GitHub rejected the token/)).toBeVisible({ timeout: 15000 });
});

test('settings: theme switch to light applies and persists', async ({ page }) => {
  await page.goto('/settings/appearance');
  await page.getByRole('button', { name: 'Light' }).click();
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'light');
  await page.reload();
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'light');
  await page.getByRole('button', { name: 'Dark' }).click();
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
});

test('settings: provider/model setup is not exposed to users', async ({ page }) => {
  await page.goto('/settings/general');
  await expect(page.locator('.settings-nav').getByText('Providers', { exact: true })).toHaveCount(0);
  await expect(page.locator('.settings-nav').getByText('Models & routing', { exact: true })).toHaveCount(0);
  await expect(page.locator('input[type=password]')).toHaveCount(0);
  await page.goto('/settings/providers');
  await expect(page).toHaveURL(/\/settings\/advanced$/);
  await expect(page.getByRole('button', { name: 'Run diagnostics' })).toBeVisible();
});

test('settings: switching to Arabic flips the whole shell to RTL', async ({ page }) => {
  await page.goto('/settings/language');
  await page.getByRole('button', { name: 'العربية' }).click();
  await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
  // sidebar labels localized
  await expect(page.locator('.sidebar').getByText('محادثة جديدة')).toBeVisible();
  await page.reload();
  await expect(page.locator('html')).toHaveAttribute('dir', 'rtl'); // persisted
  // back to English
  await page.getByRole('button', { name: 'English' }).click();
  await expect(page.locator('html')).toHaveAttribute('dir', 'ltr');
});

test('RTL: Arabic message renders with rtl direction, code stays ltr', async ({ page }) => {
  await page.goto('/chat');
  const box = page.getByPlaceholder('Message AQLEVON…');
  await box.fill('مرحبا هذه رسالة عربية طويلة مع English words و https://example.com و `inline code` للاختبار');
  await box.press('Enter');
  await expect(page.getByText(/Streamed reply about/)).toBeVisible({ timeout: 15000 });
  const bubble = page.locator('.msg.user .bubble').last();
  const dir = await bubble.evaluate(el => getComputedStyle(el).direction);
  expect(dir).toBe('rtl');
  // composer follows typing direction via dir=auto
  await box.fill('نص عربي');
  const boxDir = await box.evaluate(el => getComputedStyle(el).direction);
  expect(boxDir).toBe('rtl');
});

test('error state: unknown chat id redirects safely, no white screen', async ({ page }) => {
  await page.goto('/chat/nonexistent-id-12345');
  await expect(page).toHaveURL(/\/chat$/);
  await expect(page.getByRole('heading', { name: HERO })).toBeVisible();
});

test('no engineering terminology on user surfaces', async ({ page }) => {
  for (const path of ['/chat', '/work', '/scheduled', '/settings/general', '/settings/about']) {
    await page.goto(path);
    await expect(page.getByText(/AUTH_MODE|work\.deliverable|CONFIGURATION REQUIRED/)).toHaveCount(0);
  }
});

test('empty states are clean', async ({ page }) => {
  await page.goto('/library');
  await expect(page.locator('.lib-toolbar')).toBeVisible();
  await page.goto('/work');
  await expect(page.locator('.content')).toBeVisible();
  await page.goto('/plugins');
  await expect(page.locator('.tool-tile').first()).toBeVisible();
});

test('no horizontal overflow on desktop', async ({ page }) => {
  await page.goto('/chat');
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth);
  expect(overflow).toBe(false);
});

test('library: rename file inline and preview text content (list view)', async ({ page }) => {
  await page.goto('/library');
  const input = page.locator('input[type=file]');
  await input.setInputFiles({ name: 'rename-me.txt', mimeType: 'text/plain', buffer: Buffer.from('PREVIEW-CONTENT-123') });
  await expect(page.getByText('rename-me.txt')).toBeVisible();
  // switch to list view for table interactions
  await page.getByTitle('List view').click();
  await page.locator('tr', { hasText: 'rename-me.txt' }).getByTitle('Rename').click();
  const box = page.locator('table.filetable input.input');
  await box.fill('renamed-e2e.txt');
  await box.press('Enter');
  await expect(page.getByText('renamed-e2e.txt')).toBeVisible();
  await page.reload();
  await page.getByTitle('List view').click();
  await expect(page.getByText('renamed-e2e.txt')).toBeVisible(); // persisted
  // preview
  await page.locator('tr', { hasText: 'renamed-e2e.txt' }).locator('button.linklike').click();
  await expect(page.locator('.modal.wide')).toBeVisible();
  await expect(page.getByText('PREVIEW-CONTENT-123')).toBeVisible();
  await page.getByTitle('Close').click();
  await expect(page.locator('.modal.wide')).toHaveCount(0);
  // cleanup
  page.once('dialog', d => d.accept());
  await page.locator('tr', { hasText: 'renamed-e2e.txt' }).getByTitle('Delete').click();
});
