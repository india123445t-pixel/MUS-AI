#!/usr/bin/env node
// Launcher used by playwright.config.js webServer.
// Resets the ISOLATED e2e data dir, then boots a dedicated server instance on :3210.
// Owner data (:3000 / owner persistent volume) is never touched.
const { rmSync, mkdirSync } = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const ROOT = path.dirname(__dirname);
const DATA = path.join(ROOT, '.test-data', 'e2e');
rmSync(DATA, { recursive: true, force: true });
mkdirSync(DATA, { recursive: true });

const srv = spawn('node', ['server/index.js'], {
  cwd: ROOT, stdio: 'inherit',
  env: { ...process.env, AQLEVON_DATA_DIR: DATA, PORT: '3210', AQLEVON_MODEL_URL: process.env.TEST_AQLEVON_MODEL_URL || 'http://127.0.0.1:4998/v1', AQLEVON_MODEL_NAME: 'AQLEVON-27B' }
});
srv.on('exit', c => process.exit(c ?? 1));
process.on('SIGTERM', () => srv.kill('SIGTERM'));
process.on('SIGINT', () => srv.kill('SIGINT'));
