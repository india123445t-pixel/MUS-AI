import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = rel => fs.readFileSync(path.join(ROOT, rel), 'utf8');
const walk = dir => fs.readdirSync(path.join(ROOT, dir), { withFileTypes: true }).flatMap(ent => {
  const rel = path.join(dir, ent.name);
  return ent.isDirectory() ? walk(rel) : [rel];
});

const sourceFiles = [...walk('server'), ...walk('src')].filter(f => /\.(?:js|jsx|mjs|cjs)$/.test(f));
const source = sourceFiles.map(f => `\n/* ${f} */\n${read(f)}`).join('\n');
const ai = read('server/ai.js');
const settings = read('src/pages/SettingsPage.jsx');
const chat = read('src/pages/ChatPage.jsx');
const app = read('src/App.jsx');
const access = read('server/access.js');
const pkg = JSON.parse(read('package.json'));
const ignore = read('.gitignore');

assert.equal(pkg.name, 'aqlevon-workspace');
assert.match(app, /AQLEVON/);
assert.match(access, /process\.env\.AUTH_MODE\s*\|\|\s*['"]disabled['"]/);
assert.doesNotMatch(source, /path\s*=\s*['"]\/(?:login|signin|signup|register|auth)['"]/i);

// One sovereign model identity. Internal protocol compatibility is allowed;
// external LLM providers and their credentials are not.
assert.match(ai, /provider:\s*['"]aqlevon['"]/);
assert.match(ai, /AQLEVON_MODEL_URL/);
assert.match(ai, /AQLEVON_MODEL_NAME/);
assert.doesNotMatch(ai, /https:\/\/(?:api\.openai\.com|openrouter\.ai|generativelanguage\.googleapis\.com|api\.anthropic\.com)/i);
assert.doesNotMatch(source, /\b(?:OPENAI_API_KEY|OPENROUTER_API_KEY|GEMINI_API_KEY|ANTHROPIC_API_KEY)\b/);

// No end-user provider/model configuration surface.
assert.doesNotMatch(settings, /function\s+Provider\s*\(/);
assert.doesNotMatch(settings, /type=['"]password['"]/);
assert.doesNotMatch(chat, /model-chip/);
assert.doesNotMatch(chat, /model_mode/);
assert.match(chat, /chat\.thinkLonger/);

// Public packages must never depend on local owner data being shipped.
assert.match(ignore, /^data\/$/m);
assert.match(ignore, /^\.env$/m);

console.log(`AQLEVON_STATIC_INVARIANTS_PASS files=${sourceFiles.length}`);
