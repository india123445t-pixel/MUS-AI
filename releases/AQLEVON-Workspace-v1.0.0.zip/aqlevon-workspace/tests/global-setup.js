// E2E global setup — OWNER/TEST ISOLATION.
// playwright.config.js webServer boots a DEDICATED server on :3210 via
// tests/e2e-server.cjs, which resets AQLEVON_DATA_DIR=.test-data/e2e first:
// separate SQLite DB, file storage, repos and scheduler state.
// The owner instance (:3000, owner persistent volume) is never touched by any test.
// This setup only (1) ensures the mock AQLEVON-compatible runtime fixture is running and
// (2) waits for the isolated AQLEVON server to be ready.
import { spawn } from 'node:child_process';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const PROVIDER_PORT = 4998;

function portOpen(port) {
  return new Promise(resolve => {
    const s = net.connect(port, '127.0.0.1');
    s.once('connect', () => { s.destroy(); resolve(true); });
    s.once('error', () => { s.destroy(); resolve(false); });
  });
}

export default async function globalSetup(config) {
  const base = process.env.E2E_BASE_URL || config.projects[0]?.use?.baseURL || 'http://localhost:3210';
  if (!(await portOpen(PROVIDER_PORT))) {
    const prov = spawn('node', ['tests-server/fixtures/mock-provider.cjs'], { cwd: ROOT, stdio: 'ignore', detached: true });
    prov.unref();
    for (let i = 0; i < 40 && !(await portOpen(PROVIDER_PORT)); i++) await new Promise(r => setTimeout(r, 250));
  }
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(base + '/api/bootstrap');
      if (res.ok) return;
    } catch { /* webServer still starting; retry */ }
    await new Promise(r => setTimeout(r, 500));
  }
  throw new Error('global-setup: AQLEVON test server did not become ready at ' + base);
}
