// Mobile viewport E2E (Pixel 5).
import { test, expect } from '@playwright/test';

let consoleErrors = [];
test.beforeEach(async ({ page }) => {
  consoleErrors = [];
  page.on('pageerror', err => consoleErrors.push(err.message));
});
test.afterEach(() => expect(consoleErrors).toEqual([]));

test('mobile: app opens, composer usable, message sends', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveURL(/\/chat$/);
  const box = page.getByPlaceholder('Message AQLEVON…');
  await expect(box).toBeVisible();
  await box.fill('mobile e2e test');
  await box.press('Enter');
  await expect(page.getByText(/Streamed reply about/)).toBeVisible({ timeout: 15000 });
});

test('mobile: hamburger opens sidebar drawer and navigates', async ({ page }) => {
  test.skip((page.viewportSize()?.width || 1280) > 900, 'drawer only exists on narrow viewports');
  await page.goto('/chat');
  await expect(page.locator('.sidebar')).not.toBeInViewport();
  await page.locator('.topbar .hamburger').click();
  await expect(page.locator('.sidebar')).toBeInViewport();
  await page.locator('.sidebar').getByText('Library').click();
  await expect(page).toHaveURL(/\/library/);
  // drawer closes after navigation
  await expect(page.locator('.sidebar')).not.toBeInViewport();
});

test('mobile: no horizontal overflow on key pages', async ({ page }) => {
  for (const path of ['/chat', '/work', '/projects', '/library', '/settings/general']) {
    await page.goto(path);
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1);
    expect(overflow, path + ' overflows horizontally').toBe(false);
  }
});

test('mobile: settings nav stacks and works', async ({ page }) => {
  await page.goto('/settings/appearance');
  await expect(page.getByRole('button', { name: 'Light' })).toBeVisible();
});
