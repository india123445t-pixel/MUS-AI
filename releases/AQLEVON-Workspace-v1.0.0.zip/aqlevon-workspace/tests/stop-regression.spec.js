import { test, expect } from '@playwright/test';

// DETERMINISTIC STOP REGRESSION
// Run with AQLEVON_TEST_STOP_PERSIST_DELAY_MS=1200 on the server (npm run test:stop /
// test:e2e set it): after Stop, the server artificially delays persisting the
// partial assistant message by 1.2s — strictly longer than the old fixed 700ms
// client wait. The old timing-based client would refetch before the partial was
// persisted and drop it. The deterministic client must:
//   1. press Stop,
//   2. keep the partial visible,
//   3. wait for the server's persist acknowledgement (final `done` SSE event),
//   4. refetch and show exactly the persisted partial,
//   5. never duplicate the assistant message.

test('Stop persists the partial deterministically (persist delayed beyond 700ms)', async ({ page, request }) => {
  test.skip(Number(process.env.AQLEVON_TEST_STOP_PERSIST_DELAY_MS || 0) < 1000,
    'requires AQLEVON_TEST_STOP_PERSIST_DELAY_MS>=1000 on the server (use: npm run test:stop or AQLEVON_TEST_STOP_PERSIST_DELAY_MS=1200 npx playwright test)');
  await page.goto('/');

  // SLOW => mock AQLEVON runtime streams at 400ms/word, leaving time to press Stop.
  const box = page.getByPlaceholder('Message AQLEVON…');
  await box.fill('SLOW please write a long explanation of background tasks');
  await box.press('Enter');

  // Wait until real deltas are visible in the streaming bubble.
  const streamingMsg = page.locator('.msg.assistant .bubble').last();
  await expect(streamingMsg).toContainText(/Streamed reply/, { timeout: 20000 });
  const partialBefore = (await streamingMsg.innerText()).trim();
  expect(partialBefore.length).toBeGreaterThan(0);

  // (1) press Stop.
  const stopBtn = page.locator('.send-btn.stop');
  await expect(stopBtn).toBeVisible();
  const tStop = Date.now();
  await stopBtn.click();

  // (2) the partial must stay visible the whole time (poll while the server
  // is still inside its 1.2s artificial persist delay).
  await page.waitForTimeout(400); // well inside the delay window
  await expect(streamingMsg).toContainText(partialBefore.split('\n')[0].slice(0, 30));

  // (3+4) refetch happens only after the server acknowledged persistence:
  // busy state ends and the bubble shows the persisted text (server appends ' …').
  await expect(page.locator('.send-btn.stop')).toHaveCount(0, { timeout: 15000 });
  const persistDuration = Date.now() - tStop;
  expect(persistDuration).toBeGreaterThan(1000); // proves the ack was actually awaited

  const norm = s => s.replace(/\s+/g, ' ').trim();
  const finalBubble = page.locator('.msg.assistant .bubble').last();
  const finalText = norm(await finalBubble.innerText());
  expect(finalText).toContain('…');
  // Everything that was on screen before Stop is still there after the refetch.
  expect(finalText.startsWith(norm(partialBefore).slice(0, 25))).toBeTruthy();

  // Server-side truth: exactly this partial was persisted, exactly once.
  const chatId = page.url().match(/\/chat\/([^/?]+)/)[1];
  const chat = await (await request.get(`/api/chats/${chatId}`)).json();
  const assistants = chat.messages.filter(m => m.role === 'assistant');
  // (5) no duplicate assistant message.
  expect(assistants.length).toBe(1);
  // (4) refetch content === persisted content (rendered markdown normalizes whitespace).
  expect(norm(assistants[0].content)).toBe(finalText);
  expect(assistants[0].content.trim().endsWith('…')).toBeTruthy();

  // And the UI shows exactly one assistant bubble.
  expect(await page.locator('.msg.assistant').count()).toBe(1);
});
