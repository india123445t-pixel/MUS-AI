// Walkthrough video generator — records the direct-access AQLEVON workspace with Playwright video capture.
// READ-MOSTLY: the only writes are reversible UI-state settings posts the owner
// UI itself makes (theme/language toggles are restored to dark/en at the end).
// No chats, projects, jobs, files, schedules, repos are created or deleted.
const { chromium } = require('@playwright/test');
const fs = require('node:fs');
const path = require('node:path');

const B = process.env.WALK_BASE || 'http://localhost:3000';
const OUT = path.join(path.dirname(__dirname), 'docs', 'evidence', 'video-parts');

const pause = ms => new Promise(r => setTimeout(r, ms));

async function settle(page, ms = 1600) { await pause(ms); }

async function desktopTour(browser) {
  const ctx = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    recordVideo: { dir: OUT, size: { width: 1440, height: 900 } }
  });
  const page = await ctx.newPage();

  // 1. CHAT — empty state
  await page.goto(B + '/chat');
  await settle(page, 2200);

  // 2. AQLEVON REASONING CONTROL — same built-in runtime, no model picker
  const think = page.getByRole('button', { name: 'Think longer' });
  await think.click();
  await settle(page, 1200);
  await think.click();
  await settle(page, 700);

  // 3. TOOLS / ADD MENU
  await page.locator('.composer .chip', { hasText: 'Add' }).click();
  await settle(page, 2000);
  await page.locator('.menu-backdrop').click();
  await settle(page, 400);
  await page.locator('.composer textarea').click();
  await settle(page, 400);
  // web search + deep research toggles
  await page.locator('.chip', { hasText: 'Web search' }).click();
  await settle(page, 700);
  await page.locator('.chip', { hasText: 'Deep research' }).click();
  await settle(page, 700);
  await page.locator('.chip', { hasText: 'Web search' }).click();
  await page.locator('.chip', { hasText: 'Deep research' }).click();
  await settle(page, 500);

  // 4. CONVERSATION — open the owner's existing chat from the sidebar
  await page.locator('.sidebar .recent-item .rtitle').first().click();
  await settle(page, 2200);
  // hover a message to reveal actions
  const lastMsg = page.locator('.msg').last();
  await lastMsg.hover();
  await settle(page, 1600);

  // 5. WORK
  await page.locator('.sidebar').getByText('Work', { exact: true }).click();
  await settle(page, 1800);
  // open the new-task sheet to show the task types, then cancel (no write)
  await page.getByRole('button', { name: 'New task' }).click();
  await settle(page, 2200);
  await page.getByRole('button', { name: 'Cancel', exact: true }).click();
  await settle(page, 600);

  // 6. DEVELOPER — into the IDE
  await page.locator('.sidebar').getByText('Developer', { exact: true }).click();
  await settle(page, 1800);
  await page.locator('.app-card', { hasText: 'demo-app' }).click();
  await settle(page, 1800);
  // FILE TREE + EDITOR
  await page.locator('.tree-item', { hasText: 'README.md' }).click();
  await settle(page, 1500);
  await page.locator('.tree-item', { hasText: 'app.js' }).first().click();
  await settle(page, 1500);
  // RAIL: Terminal / Changes / Git / Checkpoints
  await page.locator('.rtab', { hasText: 'Terminal' }).click();
  await settle(page, 1200);
  await page.locator('.term-line input').fill('ls');
  await page.locator('.term-line input').press('Enter');
  await settle(page, 1800);
  await page.locator('.rtab', { hasText: 'Changes' }).click();
  await settle(page, 1500);
  await page.locator('.rtab', { hasText: 'Git' }).click();
  await settle(page, 1500);
  await page.locator('.rtab', { hasText: 'Checkpoints' }).click();
  await settle(page, 1500);

  // 7. PROJECTS
  await page.locator('.sidebar').getByText('Projects', { exact: true }).click();
  await settle(page, 1800);

  // 8. LIBRARY
  await page.locator('.sidebar').getByText('Library', { exact: true }).click();
  await settle(page, 1800);

  // 9. AUTOMATIONS
  await page.locator('.sidebar').getByText('Automations', { exact: true }).click();
  await settle(page, 1800);

  // 10. APPS
  await page.locator('.sidebar').getByText('Apps & plugins', { exact: true }).click();
  await settle(page, 2200);

  // 11. SETTINGS + AQLEVON DIAGNOSTICS
  await page.locator('.sidebar').getByText('Settings', { exact: true }).click();
  await settle(page, 1600);
  await page.locator('.settings-nav').getByText('Advanced').click();
  await settle(page, 2200);

  // 12. ENGLISH → ARABIC FULL-SHELL RTL
  await page.locator('.settings-nav').getByText('Language').click();
  await settle(page, 1200);
  await page.getByRole('button', { name: 'العربية' }).click();
  await settle(page, 2400); // full RTL shell visible
  // walk two sections in Arabic to prove full-shell localization
  await page.locator('.sidebar').getByText('المحادثات').click();
  await settle(page, 2200);
  await page.locator('.sidebar').getByText('المهام').click();
  await settle(page, 2000);
  // restore English
  await page.locator('.sidebar').getByText('الإعدادات').click();
  await settle(page, 1000);
  await page.locator('.settings-nav .navlink').nth(2).click(); // Language section
  await settle(page, 800);
  await page.getByRole('button', { name: 'English' }).click();
  await settle(page, 1600);
  await page.goto(B + '/chat');
  await settle(page, 1500);

  const video = page.video();
  await ctx.close();
  const p = await video.path();
  fs.renameSync(p, path.join(OUT, 'desktop.webm'));
}

async function mobileTour(browser) {
  const ctx = await browser.newContext({
    viewport: { width: 393, height: 851 }, isMobile: true, hasTouch: true,
    recordVideo: { dir: OUT, size: { width: 393, height: 851 } }
  });
  const page = await ctx.newPage();
  // MOBILE DRAWER
  await page.goto(B + '/chat');
  await settle(page, 1800);
  await page.locator('.topbar .hamburger').click();
  await settle(page, 2200);
  await page.locator('.sidebar').getByText('Library', { exact: true }).click();
  await settle(page, 1800);
  await page.locator('.topbar .hamburger').click();
  await settle(page, 1400);
  await page.locator('.sidebar').getByText('Chats', { exact: true }).click();
  await settle(page, 1600);
  const video = page.video();
  await ctx.close();
  const p = await video.path();
  fs.renameSync(p, path.join(OUT, 'mobile.webm'));
}

(async () => {
  fs.rmSync(OUT, { recursive: true, force: true });
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await chromium.launch();
  await desktopTour(browser);
  await mobileTour(browser);
  await browser.close();
  console.log('videos:', fs.readdirSync(OUT));
})().catch(e => { console.error(e); process.exit(1); });
