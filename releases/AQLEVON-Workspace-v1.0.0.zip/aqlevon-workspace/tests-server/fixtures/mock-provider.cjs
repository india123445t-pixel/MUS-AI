// Test fixture: OpenAI-compatible AQLEVON runtime (streaming + non-streaming) on :4998.
// Used by the automated suites (tests/global-setup.js points settings at it).
// This is verification infrastructure, not product code.
const http = require('http');
http.createServer((req, res) => {
  let body = '';
  req.on('data', c => body += c);
  req.on('end', async () => {
    let j; try { j = JSON.parse(body || '{}'); } catch { j = {}; }
    if (!Array.isArray(j.messages)) { res.end(JSON.stringify({ object: 'list', data: [{ id: 'test-model' }] })); return; }
    const last = j.messages?.[j.messages.length - 1]?.content || '';
    const slow = last.includes('SLOW');
    if (j.stream) {
      res.setHeader('Content-Type', 'text/event-stream');
      const words = ('Streamed reply about: ' + last.slice(0, 40) + ' | model=' + j.model).split(' ');
      for (const w of words) {
        res.write('data: ' + JSON.stringify({ model: j.model, choices: [{ delta: { content: w + ' ' } }] }) + '\n\n');
        await new Promise(r => setTimeout(r, slow ? 400 : 20));
      }
      res.write('data: ' + JSON.stringify({ usage: { prompt_tokens: 10, completion_tokens: words.length, total_tokens: 10 + words.length } }) + '\n\n');
      res.write('data: [DONE]\n\n');
      res.end();
    } else {
      const sys = j.messages.filter(m => m.role === 'system').map(m => m.content).join('|');
      res.end(JSON.stringify({
        model: j.model, usage: { prompt_tokens: 5, completion_tokens: 7, total_tokens: 12 },
        choices: [{ message: { content: '# Reply\n\nGenerated for: ' + last.slice(0, 80) + '\n\n## Details\n\nSYS[' + sys.slice(0, 100) + '] Some real content here with enough length to pass verification checks. More text follows to be safe.' } }]
      }));
    }
  });
}).listen(4998);
console.log('test AQLEVON runtime on 4998');
