// Backend API test suite. The isolated server points AQLEVON at a local OpenAI-compatible test runtime.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';

const B = process.env.BASE_URL || 'http://localhost:3000/api';
const j = async (path, opts = {}) => {
  const r = await fetch(B + path, {
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
    ...opts,
  });
  const text = await r.text();
  let body; try { body = JSON.parse(text); } catch { body = text; }
  return { status: r.status, body };
};

const created = { chats: [], projects: [], jobs: [], scheduled: [], files: [] };

after(async () => {
  for (const id of created.chats) await j(`/chats/${id}`, { method: 'DELETE' });
  for (const id of created.projects) await j(`/projects/${id}`, { method: 'DELETE' });
  for (const id of created.scheduled) await j(`/scheduled/${id}`, { method: 'DELETE' });
  for (const id of created.files) await j(`/files/${id}`, { method: 'DELETE' });
});

test('health: app root serves HTML without auth', async () => {
  const r = await fetch((process.env.ORIGIN || 'http://localhost:3000') + '/');
  assert.equal(r.status, 200);
  const t = await r.text();
  assert.match(t, /<div id="root">/);
});

test('chats: create, message stream, persist, delete', async () => {
  const c = await j('/chats', { method: 'POST', body: '{}' });
  assert.equal(c.status, 200);
  created.chats.push(c.body.id);

  const r = await fetch(`${B}/chats/${c.body.id}/stream`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content: 'backend suite hello' }),
  });
  assert.equal(r.status, 200);
  const text = await r.text();
  assert.match(text, /event: delta/, 'must actually stream deltas');
  assert.match(text, /event: done/);

  const got = await j(`/chats/${c.body.id}`);
  assert.equal(got.body.messages.length, 2);
  assert.equal(got.body.messages[1].role, 'assistant');
  assert.ok(got.body.messages[1].content.length > 0);
});

test('chats: pin/unpin round-trip via PATCH', async () => {
  const c = await j('/chats', { method: 'POST', body: JSON.stringify({}) });
  created.chats.push(c.body.id);
  const pin = await j(`/chats/${c.body.id}`, { method: 'PATCH', body: JSON.stringify({ pinned: true }) });
  assert.equal(pin.status, 200);
  let list = await j('/chats');
  assert.equal(list.body.find(x => x.id === c.body.id).pinned, 1, 'pinned flag must appear in list');
  await j(`/chats/${c.body.id}`, { method: 'PATCH', body: JSON.stringify({ pinned: false }) });
  list = await j('/chats');
  assert.equal(list.body.find(x => x.id === c.body.id).pinned, 0, 'unpin must persist');
});

test('bootstrap: AQLEVON is the only built-in runtime identity', async () => {
  const r = await j('/bootstrap');
  assert.equal(r.status, 200);
  assert.equal(r.body.aiConfigured, true);
  assert.equal(r.body.runtime?.provider, 'aqlevon');
  assert.equal(r.body.runtime?.model, 'AQLEVON-27B');
  assert.equal(r.body.runtime?.mode, 'self_hosted_only');
  assert.ok(!JSON.stringify(r.body).match(/openrouter|gemini|claude|gpt-4/i));
});

test('settings: UX keys persist without model/provider configuration', async () => {
  const w = await j('/settings', { method: 'POST', body: JSON.stringify({ language: 'ar', density: 'compact' }) });
  assert.equal(w.status, 200);
  const r = await j('/settings');
  assert.equal(r.body.language, 'ar');
  assert.equal(r.body.density, 'compact');
  const raw = JSON.stringify(r.body);
  assert.ok(!/ai_provider|ai_api_key|ai_model|ai_base_url|model_mode/.test(raw));
  await j('/settings', { method: 'POST', body: JSON.stringify({ language: '', density: '' }) });
});

test('chats: unknown id returns 404 JSON, not crash', async () => {
  const r = await j('/chats/does-not-exist-xyz');
  assert.equal(r.status, 404);
  assert.ok(r.body.error);
});

test('projects: isolation — project chats not in global recents', async () => {
  const p = await j('/projects', { method: 'POST', body: JSON.stringify({ name: 'suite-proj' }) });
  assert.equal(p.status, 200);
  created.projects.push(p.body.id);
  const pc = await j('/chats', { method: 'POST', body: JSON.stringify({ projectId: p.body.id }) });
  created.chats.push(pc.body.id);
  const recents = await j('/chats');
  assert.ok(!recents.body.some(c => c.id === pc.body.id), 'project chat leaked into recents');
});

test('files: UTF-8 filename upload round-trip', async () => {
  const fd = new FormData();
  fd.append('file', new Blob(['محتوى تجريبي']), 'ملف-اختبار.txt');
  const r = await fetch(`${B}/files`, { method: 'POST', body: fd });
  assert.equal(r.status, 200);
  const f = await r.json();
  created.files.push(f.id);
  assert.equal(f.name, 'ملف-اختبار.txt');
  const dl = await fetch(`${B}/files/${f.id}/content`);
  assert.equal(await dl.text(), 'محتوى تجريبي');
});

test('jobs: deliverable md end-to-end with verification evidence', async () => {
  const jb = await j('/jobs', { method: 'POST', body: JSON.stringify({ kind: 'work.deliverable', title: 'suite-md', prompt: 'short doc', format: 'md' }) });
  assert.equal(jb.status, 200);
  created.jobs.push(jb.body.id);
  let job;
  for (let i = 0; i < 40; i++) {
    await new Promise(r => setTimeout(r, 500));
    job = (await j(`/jobs/${jb.body.id}`)).body;
    if (job.status === 'done' || job.status === 'failed') break;
  }
  assert.equal(job.status, 'done');
  const res = JSON.parse(job.result);
  assert.equal(res.verification.pass, true, 'verifier must pass with evidence');
  created.files.push(res.fileId);
});

test('scheduled: validation rejects recurring without interval', async () => {
  const r = await j('/scheduled', { method: 'POST', body: JSON.stringify({ title: 'bad', kind: 'recurring', prompt: 'x' }) });
  assert.ok(r.status >= 400, `expected 4xx got ${r.status}`);
});

test('settings: provider/model credentials are not a user surface', async () => {
  const r = await j('/settings');
  assert.equal(r.status, 200);
  const raw = JSON.stringify(r.body);
  assert.ok(!/ai_provider|ai_api_key|ai_model|ai_base_url|keySource/.test(raw));
  const write = await j('/settings', { method: 'POST', body: JSON.stringify({ ai_provider: 'openrouter', ai_api_key: 'should-not-store', ai_model: 'foreign-model' }) });
  assert.equal(write.status, 200);
  const after = await j('/settings');
  assert.ok(!/openrouter|foreign-model|should-not-store/.test(JSON.stringify(after.body)));
});

test('security: XSS payload stored inert, path traversal blocked', async () => {
  const c = await j('/chats', { method: 'POST', body: '{}' });
  created.chats.push(c.body.id);
  await fetch(`${B}/chats/${c.body.id}/stream`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content: '<img src=x onerror=alert(1)>' }),
  }).then(r => r.text());
  const got = await j(`/chats/${c.body.id}`);
  assert.equal(got.body.messages[0].content, '<img src=x onerror=alert(1)>', 'stored verbatim (escaping is render-side)');
  const trav = await fetch(`${B}/files/..%2F..%2Faqlevon.db/content`);
  assert.ok(trav.status === 404 || trav.status === 400);
});

test('dev workspace: repo list + github status endpoint', async () => {
  const repos = await j('/dev/repos');
  assert.equal(repos.status, 200);
  assert.ok(Array.isArray(repos.body));
  const gh = await j('/dev/github/status');
  assert.equal(gh.status, 200);
  assert.ok('connected' in gh.body || 'configured' in gh.body);
});

test('files: rename round-trip + invalid names rejected', async () => {
  const fd = new FormData();
  fd.append('file', new Blob(['x']), 'orig.txt');
  const up = await fetch(`${B}/files`, { method: 'POST', body: fd });
  const f = await up.json();
  created.files.push(f.id);
  const ok = await j(`/files/${f.id}`, { method: 'PATCH', body: JSON.stringify({ name: 'renamed-اسم.txt' }) });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.name, 'renamed-اسم.txt');
  const bad = await j(`/files/${f.id}`, { method: 'PATCH', body: JSON.stringify({ name: '../evil' }) });
  assert.equal(bad.status, 400);
  const gone = await j('/files/nonexistent-id', { method: 'PATCH', body: JSON.stringify({ name: 'x' }) });
  assert.equal(gone.status, 404);
});

test('browser agent: SSRF guard blocks private targets', async () => {
  for (const url of ['http://localhost:3000', 'http://127.0.0.1:9', 'file:///etc/passwd', 'http://169.254.169.254/']) {
    const r = await j('/browser/sessions', { method: 'POST', body: JSON.stringify({ url }) });
    assert.equal(r.status, 400, url + ' must be blocked');
    assert.ok(r.body.error);
  }
});

test('browser agent: navigate/read/tabs/screenshot/close on real page', async () => {
  const s = await j('/browser/sessions', { method: 'POST', body: JSON.stringify({ url: 'https://example.com' }) });
  assert.equal(s.status, 200, JSON.stringify(s.body));
  const id = s.body.id;
  try {
    const read = await j(`/browser/sessions/${id}/act`, { method: 'POST', body: JSON.stringify({ type: 'read', maxChars: 500 }) });
    assert.match(read.body.untrusted_page_content, /Example Domain/);
    assert.match(read.body.content_boundary, /UNTRUSTED/);
    const tab = await j(`/browser/sessions/${id}/act`, { method: 'POST', body: JSON.stringify({ type: 'newtab', url: 'https://example.org' }) });
    assert.equal(tab.body.tabs.length, 2);
    const shot = await j(`/browser/sessions/${id}/act`, { method: 'POST', body: JSON.stringify({ type: 'screenshot' }) });
    assert.ok(shot.body.fileId, 'screenshot must be saved as a file');
    created.files.push(shot.body.fileId);
    const dl = await fetch(`${B}/files/${shot.body.fileId}/content`);
    const buf = Buffer.from(await dl.arrayBuffer());
    assert.equal(buf.subarray(0, 4).toString('hex'), '89504e47', 'must be a valid PNG');
  } finally {
    const closed = await j(`/browser/sessions/${id}`, { method: 'DELETE' });
    assert.equal(closed.body.closed, true);
  }
  const after = await j(`/browser/sessions/${id}/act`, { method: 'POST', body: JSON.stringify({ type: 'read' }) });
  assert.equal(after.status, 400, 'closed session must reject actions');
});
