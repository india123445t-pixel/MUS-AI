#!/usr/bin/env node
// Backend test runner with FULL owner/test isolation.
// Boots a dedicated server instance on PORT 3110 with AQLEVON_DATA_DIR=.test-data/backend
// (separate SQLite DB, file storage, repos, scheduler state, workspace), plus the
// mock AI provider on :4998 if not already running. The owner instance (:3000,
// owner persistent data volume) is never touched.
const { spawn } = require('node:child_process');
const net = require('node:net');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');
const DATA = path.join(ROOT, '.test-data', 'backend');
const PORT = 3110;
const PROVIDER_PORT = 4998;

function waitPort(port, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const t0 = Date.now();
    (function tryOnce() {
      const s = net.connect(port, '127.0.0.1');
      s.once('connect', () => { s.destroy(); resolve(); });
      s.once('error', () => {
        s.destroy();
        if (Date.now() - t0 > timeoutMs) reject(new Error('timeout waiting for :' + port));
        else setTimeout(tryOnce, 250);
      });
    })();
  });
}
function portOpen(port) {
  return new Promise(resolve => {
    const s = net.connect(port, '127.0.0.1');
    s.once('connect', () => { s.destroy(); resolve(true); });
    s.once('error', () => { s.destroy(); resolve(false); });
  });
}

(async () => {
  // Fresh, deterministic test state every run.
  fs.rmSync(DATA, { recursive: true, force: true });
  fs.mkdirSync(DATA, { recursive: true });

  const children = [];
  const kill = () => children.forEach(c => { try { process.kill(-c.pid, 'SIGKILL'); } catch { /* gone */ } });
  process.on('exit', kill);
  process.on('SIGINT', () => { kill(); process.exit(130); });

  if (!(await portOpen(PROVIDER_PORT))) {
    const prov = spawn('node', ['tests-server/fixtures/mock-provider.cjs'], { cwd: ROOT, stdio: 'ignore', detached: true });
    children.push(prov);
    await waitPort(PROVIDER_PORT);
  }

  const srv = spawn('node', ['server/index.js'], {
    cwd: ROOT, detached: true, stdio: ['ignore', 'pipe', 'pipe'],
    env: { ...process.env, AQLEVON_DATA_DIR: DATA, PORT: String(PORT), AQLEVON_MODEL_URL: process.env.TEST_AQLEVON_MODEL_URL || 'http://127.0.0.1:4998/v1', AQLEVON_MODEL_NAME: 'AQLEVON-27B' }
  });
  children.push(srv);
  srv.stdout.on('data', d => process.stdout.write('[test-server] ' + d));
  srv.stderr.on('data', d => process.stderr.write('[test-server] ' + d));
  await waitPort(PORT);

  const tests = spawn('node', ['--test', 'tests-server/'], {
    cwd: ROOT, stdio: 'inherit',
    env: { ...process.env, BASE_URL: `http://localhost:${PORT}/api`, ORIGIN: `http://localhost:${PORT}` }
  });
  tests.on('exit', code => { kill(); process.exit(code ?? 1); });
})().catch(e => { console.error(e); process.exit(1); });
