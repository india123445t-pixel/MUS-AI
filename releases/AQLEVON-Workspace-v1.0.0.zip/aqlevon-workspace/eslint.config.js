import js from '@eslint/js';
import react from 'eslint-plugin-react';

export default [
  { ignores: ['dist/**', 'node_modules/**', 'data/**', 'tests/**'] },
  js.configs.recommended,
  {
    files: ['src/**/*.{js,jsx}'],
    plugins: { react },
    languageOptions: {
      parserOptions: { ecmaFeatures: { jsx: true }, sourceType: 'module', ecmaVersion: 2023 },
      globals: { window: 'readonly', document: 'readonly', fetch: 'readonly', localStorage: 'readonly',
        navigator: 'readonly', speechSynthesis: 'readonly', SpeechSynthesisUtterance: 'readonly',
        alert: 'readonly', confirm: 'readonly', prompt: 'readonly', console: 'readonly',
        setTimeout: 'readonly', clearTimeout: 'readonly', setInterval: 'readonly', clearInterval: 'readonly',
        FormData: 'readonly', File: 'readonly', AbortController: 'readonly', TextDecoder: 'readonly', location: 'readonly' }
    },
    settings: { react: { version: '18' } },
    rules: {
      'react/jsx-uses-react': 'error',
      'react/jsx-uses-vars': 'error',
      'no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],
      'no-empty': ['warn', { allowEmptyCatch: true }]
    }
  },
  {
    files: ['server/**/*.js'],
    languageOptions: {
      sourceType: 'module', ecmaVersion: 2023,
      globals: { process: 'readonly', console: 'readonly', Buffer: 'readonly', URL: 'readonly',
        setTimeout: 'readonly', setInterval: 'readonly', setImmediate: 'readonly', clearInterval: 'readonly',
        fetch: 'readonly', AbortSignal: 'readonly', AbortController: 'readonly', TextDecoder: 'readonly' }
    },
    rules: { 'no-unused-vars': ['warn', { argsIgnorePattern: '^_' }], 'no-empty': ['warn', { allowEmptyCatch: true }] }
  }
];
