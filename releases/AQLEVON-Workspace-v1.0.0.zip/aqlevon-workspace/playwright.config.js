import { defineConfig, devices } from '@playwright/test';

// OWNER/TEST ISOLATION: unless E2E_BASE_URL is set explicitly, tests run against a
// DEDICATED server on :3210 (started below) whose KITE_DATA_DIR is .test-data/e2e —
// a separate database, file storage, repos and scheduler state. Tests physically
// cannot touch the owner instance on :3000.
const EXTERNAL = !!process.env.E2E_BASE_URL;
const BASE = process.env.E2E_BASE_URL || 'http://localhost:3210';

export default defineConfig({
  testDir: './tests',
  globalSetup: './tests/global-setup.js',
  timeout: 45000,
  retries: 0,
  workers: 1,
  reporter: [['list']],
  use: {
    baseURL: BASE,
    screenshot: 'only-on-failure'
  },
  webServer: EXTERNAL ? undefined : {
    command: 'node tests/e2e-server.cjs',
    url: BASE,
    reuseExistingServer: false,
    timeout: 30000
  },
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'] } },
    { name: 'mobile', use: { ...devices['Pixel 5'] }, testMatch: /mobile\.spec\.js/ }
  ]
});
