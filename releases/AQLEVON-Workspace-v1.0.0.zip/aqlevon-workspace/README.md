# AQLEVON — Direct-Access AI Workspace

AQLEVON is a direct-access AI workspace with **no login, no signup, and no model/provider setup for end users**. Opening the application opens the workspace immediately:

```text
URL → AQLEVON Workspace → AQLEVON runtime
```

The product exposes one AI identity: **AQLEVON**. Users do not choose OpenAI, Gemini, Claude, OpenRouter, a raw model ID, an endpoint, or an API key.

## Architecture

```text
aqlevon-workspace/
├── server/
│   ├── index.js    Express API + static hosting (port 3000)
│   ├── db.js       SQLite schema + default owner/workspace bootstrap
│   ├── access.js   AUTH_MODE flag (single access-decision point)
│   └── ai.js       AQLEVON-only sovereign inference adapter
├── src/            React SPA (Vite)
│   ├── pages/      Chat, Work, Developer, Projects, Library,
│   │               Plugins, Automations, Settings
│   └── components/ Search modal, Markdown renderer
└── data/           aqlevon.db + uploaded/generated files on new installs
```

Existing installations that already contain `kite.db` are opened in place so owner data is not lost. New installations use `aqlevon.db`.

## Access model

`AUTH_MODE=disabled` is the default and current public-product behavior. There are no `/login`, `/signin`, `/signup`, `/register`, or `/auth` routes.

`server/access.js` also retains an optional `owner-only` bearer-token gate for a future locked deployment. It is not enabled by default and there is no login UI.

## AQLEVON runtime

All inference goes through `server/ai.js`. The server uses one OpenAI-compatible AQLEVON endpoint and **fails closed** if that runtime is unavailable. There is no external-model fallback.

Operator-side environment variables:

```bash
AQLEVON_MODEL_URL=http://127.0.0.1:8000/v1
AQLEVON_MODEL_NAME=AQLEVON-27B
AQLEVON_MODEL_KEY=                # optional private-runtime bearer token
AQLEVON_TIMEOUT_MS=60000
```

These values are infrastructure configuration, not user settings. They are never requested in the application UI. If `AQLEVON_MODEL_URL` is omitted, the server targets the local default `http://127.0.0.1:8000/v1`.

## Features

- **Chat** — persistent conversations, streaming, Stop/Retry, auto-titles, search, web-search/deep-research toggles, edit/regenerate/branch/copy/read-aloud/dictation, file attachments, temporary chats, Markdown + code blocks.
- **Think longer** — increases reasoning effort for the same AQLEVON runtime; it is not a model selector.
- **Work** — background document, spreadsheet, presentation and research jobs with verification and Library artifacts.
- **Developer** — repository file tree, editor, terminal, diffs, Git/checkpoints and rollback flows.
- **Projects** — grouped conversations, files, tasks and project instructions.
- **Library** — uploaded and generated artifacts with preview, rename, download and filters.
- **Apps & plugins** — built-in tools plus optional external connectors such as GitHub.
- **Automations** — one-time, repeating and monitoring tasks.
- **Settings** — appearance, language, personalization, memory, web/research, data controls, diagnostics and About. There is no model/provider/API-key page.

## Run

```bash
npm ci

# development: run API and Vite separately
node server/index.js
npx vite --host 0.0.0.0

# production
npm run build
npm start
```

Copy `.env.example` to `.env` only for operator/runtime configuration. End users do not configure an AI provider.

## Acceptance criteria

A clean installation must satisfy all of the following:

1. `/` opens the workspace directly with no authentication screen.
2. No user-facing model picker, provider selector, API-key field, base URL, or raw model ID exists.
3. Chat, Work, Research, Director and automations all route to the same AQLEVON runtime.
4. A legacy client cannot force another model by sending a model identifier.
5. AQLEVON runtime failure is reported honestly; no external provider is used as a fallback.
6. Existing owner data is preserved when a legacy `kite.db` is present.
